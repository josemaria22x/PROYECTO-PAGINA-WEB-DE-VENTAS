<?php
session_start();
error_reporting(E_ALL);
ini_set("display_errors",0);
require_once("classSQL.php");

$accion =$_REQUEST['accion'];

switch ($accion) {
	case 'nuevo':
			nuevoProveedor();
		break;
	case 'editar':
			editarProveedor();
		break;
	case 'eliminar':
			eliminarProveedor();
		break;
	case 'mostrar':
			mostrarProveedor();
		break;
	
		case 'buscarnit':
			buscarNitCliente();
		break;

}


function nuevoProveedor()
{
	try
	{		
		$conexion = new conexion();
		$sql = "INSERT INTO clientes (nit,nombreproveedor, telefono, calle,numero,comuna,ciudad) 
					VALUES ('".$_REQUEST['nitproveedor']."','".utf8_decode($_REQUEST['nombreproveedor'])."', '".$_REQUEST['telefono']."','".utf8_decode($_REQUEST['calle'])."','".utf8_decode($_REQUEST['numero'])."','".utf8_decode($_REQUEST['comuna'])."','".utf8_decode($_REQUEST['ciudad'])."')";
		$regProveedor = $conexion->sqlOperacion($sql);

		if ($regProveedor["resultado"] == true ) {
			$respuesta["resultado"] = true;
			$respuesta["mensaje"] = "Datos ingresados correctamente";
		}else{
			$respuesta["resultado"] = false;
			$respuesta["mensaje"] = "Datos No ingresados";
		}

	}
	catch (Exception $e)
	{
		$respuesta['resultado']=false;
		$respuesta['mensaje']=$e;
	}

	echo json_encode( $respuesta );
	$conexion->respuestaTrans("COMMIT");
}

function editarProveedor()
{
	try
	{		
		
		$conexion = new conexion();
		$resClientes = mysql_query("UPDATE clientes SET nit='".$_REQUEST['nitproveedor']."', nombreproveedor='".utf8_decode($_REQUEST['nombreproveedor'])."',telefono='".$_REQUEST['telefono']."', calle='".utf8_decode($_REQUEST['calle'])."',numero='".utf8_decode($_REQUEST['numero'])."',comuna='".utf8_decode($_REQUEST['comuna'])."',ciudad='".utf8_decode($_REQUEST['ciudad'])."' WHERE id = ".$_REQUEST['idProveedor']);
		
		if($resClientes){
			$respuesta["resultado"] = true;
			$respuesta["mensaje"] = "Registro modificado";
		}else{
			$respuesta["resultado"] = false;
			$respuesta["mensaje"] = "Registro NO modificado ";
		}

	}
	catch (Exception $e)
	{
		$respuesta['resultado']=false;
		$respuesta['mensaje']=$e;
	}

	echo json_encode( $respuesta );
	$conexion->respuestaTrans("COMMIT");
}

function eliminarProveedor()
{
	try
	{		
		$conexion = new conexion();
		$resClientes = mysql_query("DELETE FROM clientes WHERE id={$_REQUEST['idProveedor']}");

		if($resClientes){
			$respuesta["resultado"] = true;
			$respuesta["mensaje"] = "Registro eliminado";
		}else{
			$respuesta["resultado"] = false;
			$respuesta["mensaje"] = "Registro NO eliminado ";
		}
		
	}
	catch (Exception $e)
	{
		$respuesta['resultado']=false;
		$respuesta['mensaje']=$e;
	}

	echo json_encode( $respuesta );
	$conexion->respuestaTrans("COMMIT");
}


function mostrarProveedor()
{
	try
	{	
		$conexion = new conexion();	
		if ($_REQUEST['idProveedor']) {			
			$sql="SELECT * FROM clientes  WHERE id = {$_REQUEST['idProveedor']}";
		}else{			
			$sql="SELECT * FROM clientes";			
		}	

		
		$result = $conexion->sql($sql);
		$respuesta["registros"] = $result;
		$respuesta["mensaje"] = "Datos consultados Exitosamente";
		$respuesta["resultado"] = true;

	}
	catch (Exception $e)
	{
		$respuesta['registros']=array();
		$respuesta['resultado']=false;
		$respuesta['mensaje']=$e;
	}

	echo json_encode( $respuesta );
	$conexion->respuestaTrans("COMMIT");
}


function buscarNitCliente()
{
	try
	{		
		$conexion = new conexion();
		$buscar = $conexion->sql("SELECT * FROM clientes WHERE nit = '".$_REQUEST['nit']."'");
		if (count($buscar) > 0) {
			$respuesta["registros"] = $buscar;
			$respuesta["resultado"] = true;
			$respuesta["mensaje"] = "Mostrando datos del cliente";
		}else{
			$respuesta["resultado"] = false;
			$respuesta["mensaje"] = "NIT del cliente No existe ";			
		}

	}
	catch (Exception $e)
	{
		$respuesta['resultado']=false;
		$respuesta['mensaje']=$e;
	}

	echo json_encode( $respuesta );
	$conexion->respuestaTrans("COMMIT");
}




?>