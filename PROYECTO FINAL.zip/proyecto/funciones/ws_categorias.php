<?php
session_start();
error_reporting(E_ALL);
ini_set("display_errors",0);
require_once("classSQL.php");

$accion =$_REQUEST['accion'];

switch ($accion) {
	case 'nuevo':
			nuevoCategorias();
		break;
	case 'editar':
			editarCategorias();
		break;
	case 'eliminar':
			eliminarCategorias();
		break;
	case 'mostrar':
			mostrarCategorias();
		break;
	
	
}


function nuevoCategorias()
{
	try
	{		
		$conexion = new conexion();
		$sql = "INSERT INTO categorias (descripcion,prefijo) VALUES ('".utf8_decode($_REQUEST['descripcion'])."','')";
		$regCategorias = $conexion->sqlOperacion($sql);

		if ($regCategorias["resultado"] == true ) {
			$respuesta["resultado"] = true;
			$respuesta["mensaje"] = "Datos ingresados correctamente";
		}else{
			$respuesta["resultado"] = false;
			$respuesta["mensaje"] = "Datos No ingresados";
		}
		
	}
	catch (Exception $e)
	{
		$respuesta['resultado']=false;
		$respuesta['mensaje']=$e;
	}

	echo json_encode( $respuesta );
	$conexion->respuestaTrans("COMMIT");
}

function editarCategorias()
{
	try
	{		
		$conexion = new conexion();
		$resCategorias = mysql_query("UPDATE categorias SET descripcion='".utf8_decode($_REQUEST['descripcion'])."' WHERE id = ".$_REQUEST['id']);
		
		if($resCategorias){
			$respuesta["resultado"] = true;
			$respuesta["mensaje"] = "Registro modificado";
		}else{
			$respuesta["resultado"] = false;
			$respuesta["mensaje"] = "Registro NO modificado ";
		}
		
	}
	catch (Exception $e)
	{
		$respuesta['resultado']=false;
		$respuesta['mensaje']=$e;		
	}

	echo json_encode( $respuesta );
	$conexion->respuestaTrans("COMMIT");
}

function eliminarCategorias()
{
	try
	{		
		$conexion = new conexion();
		$resCategorias = mysql_query("DELETE FROM categorias WHERE id={$_REQUEST['id']}");

		if($resCategorias){
			$respuesta["resultado"] = true;
			$respuesta["mensaje"] = "Registro eliminado";
		}else{
			$respuesta["resultado"] = false;
			$respuesta["mensaje"] = "Registro NO eliminado ";
		}
		
	}
	catch (Exception $e)
	{
		$respuesta['resultado']=false;
		$respuesta['mensaje']=$e;
	}

	echo json_encode( $respuesta );
	$conexion->respuestaTrans("COMMIT");
}


function mostrarCategorias()
{
	try
	{		
		$conexion = new conexion();
		if ($_REQUEST['id']) {			
			$sql="SELECT * FROM categorias  WHERE id = {$_REQUEST['id']} ORDER BY descripcion";
		}else{			
			$sql="SELECT * FROM categorias ORDER BY descripcion";			
			
		}	

		$result = $conexion->sql($sql);
		$respuesta["registros"] = $result;
		$respuesta["mensaje"] = "Datos consultados Exitosamente";
		$respuesta["resultado"] = true;
		
	}
	catch (Exception $e)
	{
		$respuesta['registros']=array();
		$respuesta['resultado']=false;
		$respuesta['mensaje']=$e;
	}

	echo json_encode( $respuesta );
	$conexion->respuestaTrans("COMMIT");
}



?>