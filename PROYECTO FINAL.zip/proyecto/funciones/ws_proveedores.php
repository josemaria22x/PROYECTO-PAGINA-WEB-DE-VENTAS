<?php
session_start();
error_reporting(E_ALL);
ini_set("display_errors",0);
require_once("classSQL.php");

$accion =$_REQUEST['accion'];

switch ($accion) {
	case 'nuevo':
			nuevoProveedor();
		break;
	case 'editar':
			editarProveedor();
		break;
	case 'eliminar':
			eliminarProveedor();
		break;
	case 'mostrar':
			mostrarProveedor();
		break;
	
		

}


function nuevoProveedor()
{
	try
	{		
		$conexion = new conexion();
		$sql = "INSERT INTO proveedores (nit,nombreproveedor, telefono, email, calle,numero,comuna,ciudad) 
					VALUES ('".$_REQUEST['nitproveedor']."','".utf8_decode($_REQUEST['nombreproveedor'])."', '".$_REQUEST['telefono']."', '".$_REQUEST['email']."' ,'".utf8_decode($_REQUEST['calle'])."','".utf8_decode($_REQUEST['numero'])."','".utf8_decode($_REQUEST['comuna'])."','".utf8_decode($_REQUEST['ciudad'])."')";
		$regProveedor = $conexion->sqlOperacion($sql);

		if ($regProveedor["resultado"] == true ) {
			$respuesta["resultado"] = true;
			$respuesta["mensaje"] = "Datos ingresados correctamente";
		}else{
			$respuesta["resultado"] = false;
			$respuesta["mensaje"] = "Datos No ingresados";
		}

	}
	catch (Exception $e)
	{
		$respuesta['resultado']=false;
		$respuesta['mensaje']=$e;
	}

	echo json_encode( $respuesta );
	$conexion->respuestaTrans("COMMIT");
}

function editarProveedor()
{
	try
	{		
		
		$conexion = new conexion();
		$resProveedores = mysql_query("UPDATE proveedores SET nit='".$_REQUEST['nitproveedor']."', nombreproveedor='".utf8_decode($_REQUEST['nombreproveedor'])."',telefono='".$_REQUEST['telefono']."',email='".$_REQUEST['email']."' , calle='".utf8_decode($_REQUEST['calle'])."',numero='".utf8_decode($_REQUEST['numero'])."',comuna='".utf8_decode($_REQUEST['comuna'])."',ciudad='".utf8_decode($_REQUEST['ciudad'])."' WHERE id = ".$_REQUEST['idProveedor']);
		
		if($resProveedores){
			$respuesta["resultado"] = true;
			$respuesta["mensaje"] = "Registro modificado";
		}else{
			$respuesta["resultado"] = false;
			$respuesta["mensaje"] = "Registro NO modificado ";
		}

	}
	catch (Exception $e)
	{
		$respuesta['resultado']=false;
		$respuesta['mensaje']=$e;
	}

	echo json_encode( $respuesta );
	$conexion->respuestaTrans("COMMIT");
}

function eliminarProveedor()
{
	try
	{		
		$conexion = new conexion();
		$resProveedores = mysql_query("DELETE FROM proveedores WHERE id={$_REQUEST['idProveedor']}");

		if($resProveedores){
			$respuesta["resultado"] = true;
			$respuesta["mensaje"] = "Registro eliminado";
		}else{
			$respuesta["resultado"] = false;
			$respuesta["mensaje"] = "Registro NO eliminado ";
		}
		
	}
	catch (Exception $e)
	{
		$respuesta['resultado']=false;
		$respuesta['mensaje']=$e;
	}

	echo json_encode( $respuesta );
	$conexion->respuestaTrans("COMMIT");
}


function mostrarProveedor()
{
	try
	{	
		$conexion = new conexion();	
		if ($_REQUEST['idProveedor']) {			
			$sql="SELECT * FROM proveedores  WHERE id = {$_REQUEST['idProveedor']}";
		}else{			
			$sql="SELECT * FROM proveedores";			
		}	

		
		$result = $conexion->sql($sql);
		$respuesta["registros"] = $result;
		$respuesta["mensaje"] = "Datos consultados Exitosamente";
		$respuesta["resultado"] = true;

	}
	catch (Exception $e)
	{
		$respuesta['registros']=array();
		$respuesta['resultado']=false;
		$respuesta['mensaje']=$e;
	}

	echo json_encode( $respuesta );
	$conexion->respuestaTrans("COMMIT");
}




?>