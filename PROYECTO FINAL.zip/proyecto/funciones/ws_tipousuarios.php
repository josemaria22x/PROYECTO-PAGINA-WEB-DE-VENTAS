<?php
session_start();
error_reporting(E_ALL);
ini_set("display_errors",0);
require_once("classSQL.php");

$accion =$_REQUEST['accion'];

switch ($accion) {
	case 'mostrarTU':
			mostrarTipoUsuarios();
		break;
	case 'mostrarPU':
			mostrarPermisosUsuarios();
		break;
	case 'actializarPermiso':
			actializarPermiso();
		break;
	
		
	
	
}


function mostrarTipoUsuarios()
{
	try
	{	
		$conexion = new conexion();
		if ($_REQUEST['id']) {
			$sql="SELECT * FROM tipousuarios  WHERE id = {$_REQUEST['id']}";			
		}else{
			$sql="SELECT * FROM tipousuarios";			
		}

		$result = $conexion->sql($sql);
		$respuesta["registros"] = $result;
		$respuesta["mensaje"] = "Datos consultados Exitosamente";
		$respuesta["resultado"] = true;


	}
	catch (Exception $e)
	{
		$respuesta['registros']=array();
		$respuesta['resultado']=false;
		$respuesta['mensaje']=$e;
	}

	echo json_encode( $respuesta );
	$conexion->respuestaTrans("COMMIT");
}



function mostrarPermisosUsuarios()
{
	try
	{	
		$conexion = new conexion();
		$regModulos = $conexion->sql("SELECT * FROM modulos WHERE id NOT IN (SELECT idModulo FROM permisos WHERE idTipoUsuario = {$_REQUEST['id']} ) ");
		foreach ($regModulos as $key => $value) {
			mysql_query("INSERT INTO permisos (idTipoUsuario, idModulo, acceso, crear, modificar, eliminar, consultar) VALUES ( '{$_REQUEST['id']}', '{$value['id']}', '0', '0', '0', '0', '0');");
		}

		$sql="SELECT p.Id, p.idTipoUsuario, p.idModulo, 
		IF(p.acceso = 1,'checked', '') as acceso,
		IF(p.crear = 1,'checked', '') as crear,
		IF(p.modificar = 1,'checked', '') as modificar,
		IF(p.eliminar = 1,'checked', '') as eliminar,
		IF(p.consultar = 1,'checked', '') as consultar,
		tu.descripcion as tipousuario, m.descripcion as modulo
		FROM permisos p
		INNER JOIN tipousuarios tu ON tu.id = p.idTipoUsuario
		INNER JOIN modulos m ON m.Id = p.idModulo
		WHERE p.idTipoUsuario  = {$_REQUEST['id']}";


		$result = $conexion->sql($sql);
		$respuesta["registros"] = $result;
		$respuesta["mensaje"] = "Datos consultados Exitosamente";
		$respuesta["resultado"] = true;

	}
	catch (Exception $e)
	{
		$respuesta['registros']=array();
		$respuesta['resultado']=false;
		$respuesta['mensaje']=$e;
	}

	echo json_encode( $respuesta );
	$conexion->respuestaTrans("COMMIT");
}

function actializarPermiso()
{
	try
	{
		$conexion = new conexion();
		$sql="UPDATE permisos SET ".$_REQUEST['campo']."=".$_REQUEST['valor']." WHERE id = ".$_REQUEST['id'];
		
		$respuesta = $conexion->sqlOperacion($sql);
	}
	catch (Exception $e)
	{
		$respuesta['registros']=array();
		$respuesta['resultado']=false;
		$respuesta['mensaje']=$e;
	}

	echo json_encode( $respuesta );
	$conexion->respuestaTrans("COMMIT");
}





?>