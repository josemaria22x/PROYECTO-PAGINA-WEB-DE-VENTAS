<?php
session_start();
error_reporting(E_ALL);
ini_set("display_errors",0);
require_once("classSQL.php");
$conexion = new conexion();
try
{		
	
	$username = stripslashes(mysql_real_escape_string($_REQUEST['usuario']));
	$password= sha1(strtolower($username).strip_tags(stripslashes($_REQUEST['clave'])));

	$query="SELECT u.id, u.idtipousuario, u.usuario, u.clave, u.activado, u.aleatorio, u.ultimafechaingreso, u.nombre, tp.descripcion as tipousuario			
			FROM usuarios u
			INNER JOIN tipousuarios tp ON tp.id = u.idtipousuario
			WHERE u.usuario = '{$_REQUEST['usuario']}' AND u.clave = '{$password}' AND u.activado = 1 AND u.idtipousuario <> 3";
	$resConsulta =  $conexion->sql($query);
	$_SESSION = array();

	if ( count($resConsulta) > 0 ) {
		
		$_SESSION['idusuario'] = $resConsulta[0]['id'];
		$_SESSION['usuario'] = $resConsulta[0]['usuario'];
		$_SESSION['nombre'] = $resConsulta[0]['nombre'];
		$_SESSION['idtipousuario'] = $resConsulta[0]['idtipousuario'];
		$_SESSION['tipousuario'] = $resConsulta[0]['tipousuario'];

		$fechaActual=date("Y-m-d H:i:s");
		mysql_query("UPDATE  usuarios SET  ultimafechaingreso = NOW() WHERE  id =".$resConsulta[0]['id']);
		$respuesta['mensaje']="Bienvenidos ";
		$respuesta['resultado']=true;
		
	}else{
		$respuesta['mensaje']="Verifique usuario o contraseña";
		$respuesta['resultado']=false;
	}


}
catch (Exception $e)
{
	$respuesta['registros']=array();
	$respuesta['resultado']=false;
}

echo json_encode( $respuesta );
$conexion->respuestaTrans("COMMIT");


?>