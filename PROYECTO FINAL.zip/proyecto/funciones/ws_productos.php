<?php
session_start();
error_reporting(E_ALL);
ini_set("display_errors",0);
header("Access-Control-Allow-Origin: *");
require_once("classSQL.php");

$accion =$_REQUEST['accion'];

switch ($accion) {
	case 'mostrar':
			mostrarProducto();
		break;
	case 'nuevo':
			nuevoProducto();
		break;
	case 'editar':
			editarProducto();
		break;
	case 'eliminar':
		eliminarProducto();
		break;
	case "cobrarproductos":
			cobrarProductos();
		break;	
	case 'reporteventas':
			reporteVentas();
		break;
	case 'reporteventastotales':
		reporteVentastotales();
		break;
	case 'detalleVenta':
			detalleVenta();
		break;
	case 'productosXproveedor':
			productosXproveedor();
		break;

		
		
}


function mostrarProducto()
{
	try
	{	
		$conexion = new conexion();

		if (isset($_REQUEST['id'])) {
			$sql="SELECT p.id, pu.id as idproductoubicacion, p.nombre,  p.unidadmedida,p.idproveedor, p.idcategoria, p.idsubcategoria,  p.codigo, ROUND(p.preciocompratotal,2) as preciocompratotal, ROUND(p.preciocompra,2) as preciocompra, p.divisionunidad, ROUND(p.cantidaddivision,2) as cantidaddivision, pu.precioventa, pu.existenciaminima,pu.existenciamaxima, IFNULL(SUM(pu.ingreso),0) as ingreso, IFNULL(SUM(pu.salida),0) as salida, IFNULL(SUM(pu.existencia),0) as existencia,
					IF(pu.existencia < pu.existenciaminima ,0,1) AS notificacion, p.impresion,
					(SELECT descripcion  FROM categorias WHERE id = p.idcategoria) as categoria,
					(SELECT descripcion  FROM subcategorias WHERE id = p.idsubcategoria) as subcategoria, pu.fecha_vencimiento
					FROM productos p
					LEFT JOIN productosubicaciones pu  ON pu.idproducto = p.id
					WHERE p.id = {$_REQUEST['id']}
					GROUP BY p.id,pu.id";
		}elseif (isset($_REQUEST['codigoqr'])) {
			$sql="SELECT p.id, pu.id as idproductoubicacion, p.nombre,  p.unidadmedida, p.idcategoria, p.idsubcategoria,  p.codigo, ROUND(p.preciocompratotal,2) as preciocompratotal,ROUND(p.preciocompra,2) as preciocompra, p.divisionunidad, ROUND(p.cantidaddivision,2) as cantidaddivision, pu.precioventa, pu.existenciaminima,pu.existenciamaxima, p.impresion,IFNULL(SUM(pu.existencia),0) as existencia,
					(SELECT descripcion  FROM categorias WHERE id = p.idcategoria) as categoria, IF(pu.existencia < pu.existenciaminima ,0,1) AS notificacion,
					(SELECT descripcion  FROM subcategorias WHERE id = p.idsubcategoria) as subcategoria,
					IFNULL((SELECT existencia  FROM productosubicaciones WHERE idproducto = p.id AND pu.idsucursal = 1 LIMIT 1),'0.00') as exisprincipal
					FROM productos p
					LEFT JOIN productosubicaciones pu  ON pu.idproducto = p.id
					WHERE p.codigo ='{$_REQUEST['codigoqr']}' AND pu.idsucursal = {$_REQUEST['idsucursal']}
					GROUP BY p.id,pu.id";
					
		}elseif (isset($_REQUEST['idcategoria'])) {
			$sql="SELECT p.id, pu.id as idproductoubicacion, p.nombre,  p.unidadmedida, p.idcategoria, p.idsubcategoria,  p.codigo, ROUND(p.preciocompratotal,2) as preciocompratotal,ROUND(p.preciocompra,2) as preciocompra, p.divisionunidad, ROUND(p.cantidaddivision,2) as cantidaddivision, pu.precioventa, pu.existenciaminima,pu.existenciamaxima, p.impresion,IFNULL(SUM(pu.existencia),0) as existencia,
					(SELECT descripcion  FROM categorias WHERE id = p.idcategoria) as categoria, IF(pu.existencia < pu.existenciaminima ,0,1) AS notificacion,
					(SELECT descripcion  FROM subcategorias WHERE id = p.idsubcategoria) as subcategoria,
					IFNULL((SELECT existencia  FROM productosubicaciones WHERE idproducto = p.id AND pu.idsucursal = 1 LIMIT 1),'0.00') as exisprincipal
					FROM productos p
					LEFT JOIN productosubicaciones pu  ON pu.idproducto = p.id
					WHERE p.idcategoria ={$_REQUEST['idcategoria']}
					GROUP BY p.id,pu.id";
		}else{	

				$sqlBuscarProducto = "";
				if(isset($_REQUEST['producto'])) {
					$sqlBuscarProducto = ( $_REQUEST['producto'] == '') ? '' : " AND p.nombre LIKE '%".$_REQUEST['producto']."%' OR p.codigo LIKE '%".$_REQUEST['producto']."%'";					
				}


				$sql="SELECT p.id, p.nombre,  p.unidadmedida, p.idcategoria, p.idsubcategoria, p.codigo,ROUND(p.preciocompratotal,2) as preciocompratotal, ROUND(p.preciocompra,2) as preciocompra, p.divisionunidad, ROUND(p.cantidaddivision,2) as cantidaddivision, pu.precioventa, pu.existenciaminima,pu.existenciamaxima,p.idproveedor, IFNULL(SUM(pu.ingreso),0) as ingreso, IFNULL(SUM(pu.salida),0) as salida, IFNULL(SUM(pu.existencia),0) as existencia,
					IF(IFNULL(SUM(pu.existencia),0) < pu.existenciaminima ,0,1) AS notificacion, p.impresion,
					(SELECT descripcion  FROM categorias WHERE id = p.idcategoria) as categoria, pu.id as idproductoubicacion,
					(SELECT descripcion  FROM subcategorias WHERE id = p.idsubcategoria) as subcategoria, ROUND(( p.cantidaddivision * p.preciocompra ),3) preciocosto, pu.fecha_vencimiento
					FROM productos p
					LEFT JOIN productosubicaciones pu  ON pu.idproducto = p.id  $agrupar
					WHERE pu.idsucursal = 1 $sqlBuscarProducto
					GROUP BY p.id,pu.id
					";

		}	
		

		//$respuesta["datasql"] = $sql;
		
		$result = $conexion->sql($sql);
		$respuesta["data"] = $result;

		if (count($result) > 0) {
			$respuesta["mensaje"] = "Datos consultados Exitosamente";
			$respuesta["resultado"] = true;

		}else{
			$respuesta["mensaje"] = "Datos no encotrados";
			$respuesta["resultado"] = false;
		}

	}
	catch (Exception $e)
	{
		$respuesta['data']=array();
		$respuesta['resultado']=false;
		$respuesta['mensaje']=$e;
	}

	echo json_encode( $respuesta );
	$conexion->respuestaTrans("COMMIT");
}


function nuevoProducto()
{
	try
	{		
		$conexion = new conexion();
		$conexion->transaccion();
		$error = 0;

		$idsubcategoria = isset($_REQUEST['idsubcategoria']) == "" ? "NULL" : "'".$_REQUEST['idsubcategoria']."'";
		$sql = "INSERT INTO productos ( idcategoria, idsubcategoria, codigo, nombre, unidadmedida, preciocompratotal, preciocompra, divisionunidad, cantidaddivision, impresion,idproveedor) 
					VALUES ('".$_REQUEST['idcategoria']."', $idsubcategoria, '".$_REQUEST['codigo']."', '".utf8_decode($_REQUEST['nombre'])."', '".$_REQUEST['unidadmedida']."','".$_REQUEST['preciocompratotal']."',  '".$_REQUEST['preciocompra']."', '".$_REQUEST['divisionunidad']."', '".$_REQUEST['cantidaddivision']."', '0' , '".$_REQUEST['idproveedor']."')";
		
		$regProducto = $conexion->sqlOperacion($sql);
		if ($regProducto["resultado"] == true) {
			$sql = "INSERT INTO productosubicaciones(idsucursal, idproducto, precioventa, ingreso, salida, existencia, existenciaminima, existenciamaxima, estado, ordencompra) 
					VALUES ('1','".$regProducto["ultimoId"]."','".$_REQUEST['precioventa']."', '0','0','0','".$_REQUEST['existenciaminima']."', '".$_REQUEST['existenciamaxima']."','0','0')";
			if($conexion->sqlOperacion($sql)["resultado"] == false){ $error++; }
			

			/*if (isset($_REQUEST["sucursal1"])) {
				$sql = "INSERT INTO productosubicaciones(idsucursal, idproducto, precioventa, ingreso, salida, existencia, existenciaminima, existenciamaxima, estado, ordencompra) 
							VALUES ('2','".$regProducto["ultimoId"]."','".$_REQUEST['precioventa']."', '0','0','0','".$_REQUEST['existenciaminima']."', '".$_REQUEST['existenciamaxima']."','0','0')";
					if($conexion->sqlOperacion($sql)["resultado"] == false){ $error++; }
			}

			if (isset($_REQUEST["sucursal2"])) {
				$sql = "INSERT INTO productosubicaciones(idsucursal, idproducto, precioventa, ingreso, salida, existencia, existenciaminima, existenciamaxima, estado, ordencompra) 
							VALUES ('3','".$regProducto["ultimoId"]."','".$_REQUEST['precioventa']."', '0','0','0','".$_REQUEST['existenciaminima']."', '".$_REQUEST['existenciamaxima']."','0','0')";
					if($conexion->sqlOperacion($sql)["resultado"] == false){ $error++; }
			}*/
			
		}else{
			$error++;
		}

		
		if (!$error) {
			$respuesta["resultado"] = true;
			$respuesta["mensaje"] = "Datos ingresados correctamente";
			$conexion->respuestaTrans("COMMIT");
		}else{
			$respuesta["resultado"] = false;
			$respuesta["mensaje"] = "Datos No ingresados";
			$conexion->respuestaTrans("ROLLBACK");
		}

	}
	catch (Exception $e)
	{
		$respuesta['resultado']=false;
		$respuesta['mensaje']=$e;
	}

	echo json_encode( $respuesta );
	$conexion->respuestaTrans("COMMIT");
}


function editarProducto()
{
	try
	{		
		$conexion = new conexion();
		$conexion->transaccion();
		$error = 0;

		$idsubcategoria = isset($_REQUEST['idsubcategoria']) == "" ? "NULL" : "'".$_REQUEST['idsubcategoria']."'";
		$sql = "UPDATE productos SET idcategoria='".$_REQUEST['idcategoria']."', idsubcategoria=$idsubcategoria, nombre='".utf8_decode($_REQUEST['nombre'])."', codigo='".$_REQUEST['codigo']."', preciocompra='".$_REQUEST['preciocompra']."', idproveedor='".$_REQUEST['idproveedor']."' WHERE id = ".$_REQUEST['id'];
		if($conexion->sqlOperacion($sql)["resultado"] == false){ $error++; }

		$sql = "UPDATE productosubicaciones SET existenciaminima='".$_REQUEST['existenciaminima']."',existenciamaxima='".$_REQUEST['existenciamaxima']."' , precioventa='".$_REQUEST['precioventa']."' WHERE idproducto = ".$_REQUEST['id'];
		if($conexion->sqlOperacion($sql)["resultado"] == false){ $error++; }
		
		if(!$error){
			$conexion->respuestaTrans("COMMIT");
			$respuesta["resultado"] = true;
			$respuesta["mensaje"] = "Registro modificado";
		}else{
			$respuesta["resultado"] = false;
			$respuesta["mensaje"] = "Registro NO modificado ";
			$conexion->respuestaTrans("ROLLBACK");
		}

	}
	catch (Exception $e)
	{
		$respuesta['resultado']=false;
		$respuesta['mensaje']=$e;
	}

	echo json_encode( $respuesta );
	$conexion->respuestaTrans("COMMIT");
}


function eliminarProducto()
{
	try
	{		
		$conexion = new conexion();
		$conexion->transaccion();
		$error = 0;


		$sql = "DELETE FROM productosubicaciones WHERE idproducto={$_REQUEST['id']}";
		if($conexion->sqlOperacion($sql)["resultado"] == false){ $error++; }

		$sql = "DELETE FROM productos WHERE id={$_REQUEST['id']}";
		if($conexion->sqlOperacion($sql)["resultado"] == false){ $error++; }

		if (!$error) {
			$respuesta["resultado"] = true;
			$respuesta["mensaje"] = "Operación realizada con exito";
			$conexion->respuestaTrans("COMMIT");
		}else{
			$respuesta["resultado"] = false;
			$respuesta["mensaje"] = "Operación NO realizada";
			$conexion->respuestaTrans("ROLLBACK");
		}
	}
	catch (Exception $e)
	{
		$respuesta['resultado']=false;
		$respuesta['mensaje']=$e;
	}

	echo json_encode( $respuesta );
	$conexion->respuestaTrans("COMMIT");
}



function cobrarProductos()
{
	try {

		$conexion = new conexion();
		$conexion->transaccion();
		$error = 0;
		$idventa = 0;		
		
		$sql = "INSERT INTO ventas(idcliente, idusuario,fechahora,totalventa) 
		VALUES ('".$_REQUEST['idcliente']."','".$_SESSION["idusuario"]."',now(),'0')";	
		
		$regVenta = $conexion->sqlOperacion($sql);
		$idventa = $regVenta['ultimoId'];
		if ($regVenta['resultado'] == false) {  /*echo "2"*/ ; $error++;  }
		
		if (!$error) {
				$pedido = preg_replace("/([a-zA-Z0-9_]+?):/" , "\"$1\":", $_REQUEST["pedido"]); // fix variable names 
				$arrayPedido = json_decode($pedido, true); 
				$precioventa = 0;

				foreach ($arrayPedido as $key => $value) {
					$value['cantidad'] = isset($value['cantidad'])  ?  $value['cantidad'] : 1 ;
					$precioventa += ($value['cantidad'] * $value["precioventa"]);
					
					$sql = "INSERT INTO ventasdetalles(idventa, idproductoubicacion, cantidad) 
					VALUES ('".$idventa."', '".$value["idproductoubicacion"]."', '".$value["cantidad"]."')";
					if ($conexion->sqlOperacion($sql)['resultado'] == false) { $error++; }					

				}

			$sql = "UPDATE ventas SET totalventa = '$precioventa' WHERE id = $idventa";
			if ($conexion->sqlOperacion($sql)["resultado"] == false) { $error++; }
		}

		if (!$error) {
			$conexion->respuestaTrans("COMMIT");
			$respuesta["resultado"] = true;
			$respuesta["mensaje"] = "Datos ingresados correctamente";

		}else{
			$conexion->respuestaTrans("ROLLBACK");
			$respuesta["resultado"] = false;
			$respuesta["mensaje"] = "Datos No ingresados";
		}

	}catch (Exception $e) {
		$conexion->respuestaTrans("ROLLBACK");
		$respuesta["resultado"] = false;
		$respuesta["mensaje"] = $e->getMessage();
	}

	echo json_encode( $respuesta );
	
}



function reporteVentas()
{
	try
	{	
		$conexion = new conexion();		
		
		$f1 = explode(" ", $_REQUEST['fechainicio']);
		$fechainicio = $_REQUEST['fechainicio'];
		if ( isset($f1[0]) && !isset($f1[1]) ) {
			$fechainicio = $_REQUEST['fechainicio']." 00:00:00";
		}

		$f2 = explode(" ", $_REQUEST['fechafin']);
		$fechafin = $_REQUEST['fechafin'];
		if ( isset($f2[0]) && !isset($f2[1]) ) {
			$fechafin = $_REQUEST['fechafin']." 23:59:59";
		}

		$sql="SELECT ventas.*, productos.*, COUNT(productos.id) as cantidad FROM ventas
		INNER JOIN ventasdetalles ON ventas.id = ventasdetalles.idventa
		INNER JOIN productosubicaciones ON ventasdetalles.idproductoubicacion = productosubicaciones.id
		INNER JOIN productos ON productosubicaciones.idproducto = productos.id
		WHERE fechahora BETWEEN '".date("Y-m-d H:i:s",strtotime($fechainicio))."' AND '".date("Y-m-d H:i:s",strtotime($fechafin))."'
		GROUP BY productos.id
		ORDER BY cantidad DESC";
		$result = $conexion->sql($sql);
		
		if($result){
			$respuesta["ventas"] = $result;
			$respuesta["resultado"] = true;
			$respuesta["mensaje"] = "Reporte consultado con exito";
		}else{
			$respuesta["resultado"] = false;
			$respuesta["mensaje"] = "No hay datos para mostrar ";
		}
		
	}
	catch (Exception $e)
	{
		$respuesta['resultado']=false;
		$respuesta['mensaje']=$e;
	}
	
	echo json_encode($respuesta);
	$conexion->respuestaTrans("COMMIT");
	
}



function reporteventastotales()
{
	try
	{	
		$conexion = new conexion();		
		
		$f1 = explode(" ", $_REQUEST['fechainicio']);
		$fechainicio = $_REQUEST['fechainicio'];
		if ( isset($f1[0]) && !isset($f1[1]) ) {
			$fechainicio = $_REQUEST['fechainicio']." 00:00:00";
		}

		$f2 = explode(" ", $_REQUEST['fechafin']);
		$fechafin = $_REQUEST['fechafin'];
		if ( isset($f2[0]) && !isset($f2[1]) ) {
			$fechafin = $_REQUEST['fechafin']." 23:59:59";
		}

		$sql="SELECT * FROM ventas
		WHERE fechahora BETWEEN '".date("Y-m-d H:i:s",strtotime($fechainicio))."' AND '".date("Y-m-d H:i:s",strtotime($fechafin))."'";
		$result = $conexion->sql($sql);
		
		if($result){
			$respuesta["ventas"] = $result;
			$respuesta["resultado"] = true;
			$respuesta["mensaje"] = "Reporte consultado con exito";
		}else{
			$respuesta["resultado"] = false;
			$respuesta["mensaje"] = "No hay datos para mostrar ";
		}
		
	}
	catch (Exception $e)
	{
		$respuesta['resultado']=false;
		$respuesta['mensaje']=$e;
	}
	
	echo json_encode($respuesta);
	$conexion->respuestaTrans("COMMIT");
	
}


function detalleVenta()
{
	try
	{	
		$conexion = new conexion();		
		$sql = "SELECT productos.*, productosubicaciones.precioventa FROM ventasdetalles
		INNER JOIN productosubicaciones ON ventasdetalles.idproductoubicacion = productosubicaciones.id
		INNER JOIN productos ON productosubicaciones.idproducto = productos.id
		WHERE ventasdetalles.idventa = ".$_REQUEST['id'];
		
		
		$result = $conexion->sql($sql);
		
		if($result){
			$respuesta["ventas"] = $result;
			$respuesta["resultado"] = true;
			$respuesta["mensaje"] = "Reporte consultado con exito";
		}else{
			$respuesta["resultado"] = false;
			$respuesta["mensaje"] = "No hay datos para mostrar ";
		}
		
	}
	catch (Exception $e)
	{
		$respuesta['resultado']=false;
		$respuesta['mensaje']=$e;
	}
	
	echo json_encode($respuesta);
	$conexion->respuestaTrans("COMMIT");
	
}


function productosXproveedor()
{
	try
	{	
		$conexion = new conexion();		
		$sql = "SELECT * FROM productos
		INNER JOIN proveedores ON productos.idproveedor = proveedores.id";
		
		
		$result = $conexion->sql($sql);
		
		if($result){
			$respuesta["ventas"] = $result;
			$respuesta["resultado"] = true;
			$respuesta["mensaje"] = "Reporte consultado con exito";
		}else{
			$respuesta["resultado"] = false;
			$respuesta["mensaje"] = "No hay datos para mostrar ";
		}
		
	}
	catch (Exception $e)
	{
		$respuesta['resultado']=false;
		$respuesta['mensaje']=$e;
	}
	
	echo json_encode($respuesta);
	$conexion->respuestaTrans("COMMIT");
	
}



?>