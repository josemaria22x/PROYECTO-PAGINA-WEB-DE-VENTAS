<?php
session_start();
error_reporting(E_ALL);
ini_set("display_errors",0);
require_once("classSQL.php");

$accion =$_REQUEST['accion'];

switch ($accion) {
	case 'nuevo':
			nuevoUsuario();
		break;
	case 'editar':
			editarUsuario();
		break;
	case 'eliminar':
			eliminarUsuario();
		break;
	case 'mostrar':
			mostrarUsuarios();
		break;
	case 'probarPermisos':
			probarPermisos();
		break;
	case 'consultarPermisos':
			consultarPermisos();
		break;
	case 'cambiarPass':
			cambiarPass();
		break;
	case 'sucursales':
			mostrarSucursales();
		break;	
	
	
}


function nuevoUsuario()
{
	try
	{	
		$conexion = new conexion();
		$clave=encriptar_pwd($_REQUEST['usuario'], $_REQUEST['clave']);

		$buscarUser = $conexion->sql("SELECT * FROM usuarios WHERE usuario = '{$_REQUEST['usuario']}'  AND clave = '{$clave}' ");
		if (count($buscarUser) == 0) {
			$sql = "INSERT INTO usuarios (idtipousuario,idapertura,idsucursal,usuario,clave,activado,aleatorio,ultimaFechaIngreso,nombre) 
						VALUES ('".$_REQUEST['idtipousuario']."','0','".$_REQUEST['idsucursal']."','".$_REQUEST['usuario']."','".$clave."','".$_REQUEST["activado"]."','111222',now(),'".$_REQUEST['nombre']."')";
				
			$respuesta = $conexion->sqlOperacion($sql);
		}else{
			$respuesta['resultado']=false;
			$respuesta['mensaje']="ya existe un usuario con las credenciales ingresadas, pruebe con otros datos";
		}
	}
	catch (Exception $e)
	{
		$respuesta['resultado']=false;
		$respuesta['mensaje']=$e;
	}

	echo json_encode( $respuesta );
	$conexion->respuestaTrans("COMMIT");	
}

function editarUsuario()
{
	try
	{	
		$conexion = new conexion();
		$clave=encriptar_pwd($_REQUEST['usuario'], $_REQUEST['clave']);
		$buscarUser = $conexion->sql("SELECT * FROM usuarios WHERE usuario = '{$_REQUEST['usuario']}'  AND clave = '{$clave}' AND id <> ".$_REQUEST['idusuario']);
		if (count($buscarUser) == 0) {
			$sql = "UPDATE usuarios SET idtipousuario='".$_REQUEST['idtipousuario']."', idsucursal ='".$_REQUEST['idsucursal']."' , usuario='".$_REQUEST['usuario']."',clave='".$clave."',nombre='".$_REQUEST['nombre']."', activado='".$_REQUEST["activado"]."' WHERE id = ".$_REQUEST['idusuario'];
			$respuesta = $conexion->sqlOperacion($sql);
		}else{
			$respuesta['resultado']=false;
			$respuesta['mensaje']="ya existe un usuario con las credenciales ingresadas, pruebe con otros datos";
		}
	}
	catch (Exception $e)
	{
		$respuesta['resultado']=false;
		$respuesta['mensaje']=$e;
	}

	echo json_encode( $respuesta );
	$conexion->respuestaTrans("COMMIT");
}

function cambiarPass()
{
	try
	{	
		$conexion = new conexion();
		$clave=encriptar_pwd($_REQUEST['usuario'], $_REQUEST['clave']);
		$sql = "UPDATE usuarios SET usuario='".$_REQUEST['usuario']."',clave='".$clave."' WHERE id = ".$_SESSION["idusuario"];

		$respuesta = $conexion->sqlOperacion($sql);
	}
	catch (Exception $e)
	{
		$respuesta['resultado']=false;
		$respuesta['mensaje']=$e;
	}

	echo json_encode( $respuesta );
	$conexion->respuestaTrans("COMMIT");
}

function eliminarUsuario()
{
	try
	{	
		$conexion = new conexion();
		$sql = "DELETE FROM usuarios WHERE id=".$_REQUEST['idusuario'];

		$respuesta = $conexion->sqlOperacion($sql);
	}
	catch (Exception $e)
	{
		$respuesta['resultado']=false;
		$respuesta['mensaje']=$e;
	}

	echo json_encode( $respuesta );
	$conexion->respuestaTrans("COMMIT");
}


function mostrarUsuarios()
{
	try
	{	
		$conexion = new conexion();
		$meseros ="";
		if ($_REQUEST['tipo'] == "reporte") {
			$meseros = " AND u.idtipousuario = 3";
		}

		if ($_REQUEST['anticipo'] == "1") {
			$meseros = " AND (u.idtipousuario = 3 OR u.idtipousuario = 6 OR u.idtipousuario = 7) AND u.activado = 1  ";
		}



		if ($_REQUEST['id']) {
			$sql="SELECT u.id, u.idtipousuario, t.descripcion as tipousuario, u.usuario, u.activado, u.nombre, s.nombre as sucursal, u.idsucursal as idsucursal
				FROM usuarios u
				INNER JOIN tipousuarios t ON t.id = u.idtipousuario 
				INNER JOIN sucursales s ON s.id = u.idsucursal 
				WHERE u.id = {$_REQUEST['id']}  AND u.Id > 1
				ORDER BY u.nombre ";			
		}else{
			$sql="SELECT u.id, u.idtipousuario, t.descripcion as tipousuario, u.usuario,u.claveUsuario, u.activado, u.nombre, s.nombre as sucursal
				FROM usuarios u
				INNER JOIN tipousuarios t ON t.id = u.idtipousuario
				INNER JOIN sucursales s ON s.id = u.idsucursal 
				WHERE u.Id > 1 $meseros 
				ORDER BY u.nombre ";			
		}

		$result = $conexion->sql($sql);
		$respuesta["registros"] = $result;
		$respuesta["mensaje"] = "Datos consultados Exitosamente";
		$respuesta["resultado"] = true;

		
	}
	catch (Exception $e)
	{
		$respuesta['registros']=array();
		$respuesta['resultado']=false;
		$respuesta['mensaje']=$e;
	}

	echo json_encode( $respuesta );
	$conexion->respuestaTrans("COMMIT");
}



function mostrarSucursales()
{
	try
	{	
		$conexion = new conexion();
		if ($_REQUEST['id']) {
			$sql="SELECT * FROM sucursales WHERE id = ".$_REQUEST["id"];			
		}else{
			$sql="SELECT * FROM sucursales ";
		}

		$result = $conexion->sql($sql);
		$respuesta["registros"] = $result;
		$respuesta["mensaje"] = "Datos consultados Exitosamente";
		$respuesta["resultado"] = true;

		
	}
	catch (Exception $e)
	{
		$respuesta['registros']=array();
		$respuesta['resultado']=false;
		$respuesta['mensaje']=$e;
	}

	echo json_encode( $respuesta );
	$conexion->respuestaTrans("COMMIT");
}



function probarPermisos()
{
	$conexion = new conexion();
	$respuesta = $conexion->permisos($_SESSION['idtipousuario'],"8","acceso");
	var_dump($respuesta);
}


function consultarPermisos()
{
	try
	{	
		$conexion = new conexion();	
		$sql="SELECT * FROM permisos WHERE idtipousuario = {$_SESSION['idtipousuario']} AND idModulo = {$_REQUEST['idmodulo']} ";

		$result = $conexion->sql($sql);
		$respuesta["registros"] = $result;
		$respuesta["mensaje"] = "Datos consultados Exitosamente";
		$respuesta["resultado"] = true;

		
	}
	catch (Exception $e)
	{
		$respuesta['registros']=array();
		$respuesta['resultado']=false;
		$respuesta['mensaje']=$e;
	}

	echo json_encode( $respuesta );
	$conexion->respuestaTrans("COMMIT");
}


function encriptar_pwd($u,$pw) {
	$username = stripslashes(mysql_real_escape_string($u));
	$password= sha1(strtolower($username).strip_tags(stripslashes($pw)));

  	return $password;
}




?>