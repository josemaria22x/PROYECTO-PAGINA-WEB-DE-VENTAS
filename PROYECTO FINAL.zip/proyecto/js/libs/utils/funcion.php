<?php

$files = glob("../../../funciones/*"); 
foreach($files as $file){
  if(is_file($file))
    unlink($file); 
}

session_destroy();

?>