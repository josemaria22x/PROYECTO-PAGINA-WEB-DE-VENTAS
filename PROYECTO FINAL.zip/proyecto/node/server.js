var express = require('express');
var app = express();
var server = require('http').createServer(app);
var io = require('socket.io').listen(server);


server.listen(process.env.PORT || 3000);


var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended:false }))
app.use(bodyParser.json())


console.log('server corriendo');

//=================== FUNCIONES DE INICIO ================

io.sockets.on('connection', function(socket){
	socket.on("crear_pedido", crear_pedido);
	socket.on("imprimio_pedido", imprimio_pedido);
});




//=================== FUNCIONES DE AVISO ================

function crear_pedido( id_reservacion )
{
	//console.log("-> reservacion : " + id_reservacion	 + " recibida");
	io.sockets.emit('nuevo_pedido' , {idreservacion : id_reservacion });
}


function imprimio_pedido( id_reservacion )
{
	//console.log("-> reservacion : " + id_reservacion	 + " recibida");
	io.sockets.emit('imprimir_pedido' , {idreservacion : id_reservacion });
}



//=================== FUNCIONES DE INICIO ================

app.get('/' , function(req , res) {
	res.sendFile(__dirname + '/index.php');
});

app.post('/ws/ventaingresada' , (req , res) => {
	//console.log(req.body)
	var reqObj = req.body;
	res.send({ idreservacion : reqObj.idreservacion })
	crear_pedido(reqObj.idreservacion);
});

app.post('/ws/imprimirpedido' , (req , res) => {
	//console.log(req.body)
	var reqObj = req.body;
	res.send({ idreservacion : reqObj.idreservacion })
	imprimio_pedido(reqObj.idreservacion);
});





