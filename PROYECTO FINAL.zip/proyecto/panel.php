<?php 
include('header.php'); 
?>

	<script src="js/libs/sammy/sammy.js"></script>

	<script type="text/javascript">
	  var ratPack = $.sammy(function(e) {	  	
	    this.element_selector = '#content';
	  
		this.get('#/', function(context) {
	      	context.app.swap('');
	      	$("#main-menu").find('li').removeClass('active');
	      	context.partial("modulos/usuarios.php",function(){});
	      	$("#menu-usuarios").parent().addClass('active');
	      	$('body').removeClass('menubar-visible');
	    });

		

	    this.get('#/usuarios', function(context) {
	      	context.app.swap('');
	      	$("#main-menu").find('li').removeClass('active');
	      	context.partial("modulos/usuarios.php",function(){});
	      	$("#menu-usuarios").parent().addClass('active');
	      	$('body').removeClass('menubar-visible');	      	
	    });	    



		this.get('#/permisos', function(context) {
	      	context.app.swap('');
	      	$("#main-menu").find('li').removeClass('active');
	      	context.partial("modulos/permisos.php",function(){});
	      	$("#menu-permisos").parent().addClass('active');
	      	$('body').removeClass('menubar-visible');	      	
	    });	



		this.get('#/proveedores', function(context) {
	      	context.app.swap('');
	      	$("#main-menu").find('li').removeClass('active');
	      	context.partial("modulos/proveedores.php",function(){});
	      	$("#menu-proveedores").parent().addClass('active');
	      	$('body').removeClass('menubar-visible');	      	
	    });	


		this.get('#/productos', function(context) {
	      	context.app.swap('');
	      	$("#main-menu").find('li').removeClass('active');
	      	context.partial("modulos/productos.php",function(){});
	      	$("#menu-productos").parent().addClass('active');
	      	$('body').removeClass('menubar-visible');	      	
	    });	

		this.get('#/clientes', function(context) {
	      	context.app.swap('');
	      	$("#main-menu").find('li').removeClass('active');
	      	context.partial("modulos/clientes.php",function(){});
	      	$("#menu-clientes").parent().addClass('active');
	      	$('body').removeClass('menubar-visible');	      	
	    });	
		
		
		this.get('#/ventas', function(context) {
	      	context.app.swap('');
	      	$("#main-menu").find('li').removeClass('active');
	      	context.partial("modulos/ventas.php",function(){});
	      	$("#menu-ventas").parent().addClass('active');
	      	$('body').removeClass('menubar-visible');	      	
	    });	


		this.get('#/repProductos', function(context) {
	      	context.app.swap('');
	      	$("#main-menu").find('li').removeClass('active');
	      	context.partial("modulos/repProductos.php",function(){});
	      	$("#menu-repProductos").parent().addClass('active');
	      	$('body').removeClass('menubar-visible');	      	
	    });	

		this.get('#/repVentas', function(context) {
	      	context.app.swap('');
	      	$("#main-menu").find('li').removeClass('active');
	      	context.partial("modulos/repVentas.php",function(){});
	      	$("#menu-repVentas").parent().addClass('active');
	      	$('body').removeClass('menubar-visible');	      	
	    });	

		this.get('#/repProveedores', function(context) {
	      	context.app.swap('');
	      	$("#main-menu").find('li').removeClass('active');
	      	context.partial("modulos/repProveedores.php",function(){});
	      	$("#menu-repProveedores").parent().addClass('active');
	      	$('body').removeClass('menubar-visible');	      	
	    });	
		
		
		



		this.get('#/categorias', function(context) {
	    	context.app.swap('');	    	
	    	context.partial("modulos/categorias.php",function(){});	
	    });    
		


	    this.notFound = function(context,url){
           	console.log("Url no encontrada");
        }


    });
	
	$(function() {
		ratPack.run('#/');
	});

  </script>

<?php include('footer.php'); ?>