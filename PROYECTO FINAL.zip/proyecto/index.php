<?php 
session_start(); error_reporting(0);
if($_GET[a]=="logout")
{
  session_destroy();
  header ("Location: index.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="shortcut icon" href="images/favicon.png" type="image/png">

  <title>[ Login ]</title>

    <script type="text/javascript"  src="js/libs/jquery/jquery-1.11.2.js"></script>
    <script type="text/javascript" src="js/libs/jquery/jquery.blockUI.js"></script>
    <script type="text/javascript" src="js/funciones.js"></script>
    

    <script src="js/index.js"></script>
    
    <script src="js/libs/toastr/toastr.js"></script>

    <link type="text/css" rel="stylesheet" href="css/theme-2/libs/toastr/toastr.css">

   <!-- Bootstrap CSS-->
   <link href="vendor/bootstrap-4.1/bootstrap11.min.css" rel="stylesheet" media="all">

   <!-- Fontfaces CSS-->
   <link href="css-cp/font-face.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css-cp/theme.css" rel="stylesheet" media="all">
  
 
</head>

<body class="animsition">
    


  <!-- PRELOADER -->
    <div id='mensaje' style='display:none;'> <!--<img src="img/loader1.gif" width="48" height="48" />-->
        <div class="blockMsg">Cargando espere un momento<br><br><br></div>
        <div class="circle"></div>
        <div class="circle1"></div>
    </div> <!-- end PRELOADER -->



    
    <div class="page-wrapper">
        <div class="page-content--bge5">
            <div class="container">
                <div class="login-wrap">
                    <div class="login-content">
                        <div class="login-logo">
                           
                            <h1>Inicio de sesión</h1>
                        
                        </div>
                        <div class="login-form">
                            <form id="form-login">
                                <div class="form-group">
                                    <label>Usuario</label>
                                    <input class="au-input au-input--full" type="text" name="usuario" placeholder="Ingrese el Usuario">
                                </div>
                                <div class="form-group">
                                    <label>Clave</label>
                                    <input class="au-input au-input--full" type="password" name="clave" placeholder="Ingrese la clave">
                                </div>
                          
                                <button id="btn-login" class="au-btn au-btn--block au-btn--blue m-b-20" type="submit">Ingresar</button>
                               
                            </form>
                      
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>




<script>
$(function(){
    

    $("#btn-login").on('click',function(e){
      e.preventDefault();
      bloquearPantalla("Espere por favor");
      $.getJSON("funciones/ws_login.php" , $("#form-login").serialize() ,function(data) {
          if (!data.resultado) 
          {
              toastr.error(data.mensaje,"Información");
              desbloquearPantalla();
          } else {
              setTimeout("window.location.href = 'panel.php'", 700);
              desbloquearPantalla();
          }
      })
      .fail(function() {
          alert(data.mensaje);
          desbloquearPantalla();
      });
    });

});


</script>
<?php include('footer.php'); ?>
</body>
</html>