<?php 
session_start(); 
if(!$_SESSION["usuario"]) 
{ 
  $_SESSION['redirect'] = 'http://'.$_SERVER["HTTP_HOST"].$_SERVER['REQUEST_URI']; 
  header ("Location: index.php"); 
} 
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<link rel="shortcut icon" href="images/success.png" type="image/png">
		<title>UMG</title>

		<!-- BEGIN META -->
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="keywords" content="your,keywords">
		<meta name="description" content="Short explanation about this website">
		<!-- END META -->

		<!-- Bootstrap CSS-->
		<link href="vendor/bootstrap-4.1/bootstrap8.min.css" rel="stylesheet" media="all">
		<!-- BEGIN STYLESHEETS -->		
		<link type="text/css" rel="stylesheet" href="css/theme-2/materialadmin0.css?1425466319" />

		<link type="text/css" rel="stylesheet" href="css/theme-2/libs/toastr/toastr.css">
		<link type="text/css" rel="stylesheet" href="css/theme-2/libs/DataTables/jquery.dataTables.css" />
		<link type="text/css" rel="stylesheet" href="css/theme-2/libs/DataTables/extensions/dataTables.colVis.css" />
		<link type="text/css" rel="stylesheet" href="css/theme-2/libs/DataTables/extensions/dataTables.tableTools.css" />
		<link type="text/css" rel="stylesheet" href="css/theme-2/libs/select2/select2.css" />
		<link type="text/css" rel="stylesheet" href="css/theme-2/libs/bootstrap-datetimepicker/bootstrap-datetimepicker.min.css" />

		
		<!-- END STYLESHEETS -->


		<!-- Fontfaces CSS-->
		<link href="css-cp/font-face.css" rel="stylesheet" media="all">
		<link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
		<link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
		<link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">



		<!-- Vendor CSS-->
		<link href="vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
		<link href="vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
		<link href="vendor/wow/animate.css" rel="stylesheet" media="all">
		<link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
		<link href="vendor/slick/slick.css" rel="stylesheet" media="all">
		<link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
		<link href="vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">

		<!-- Main CSS-->
		<link href="css-cp/theme.css" rel="stylesheet" media="all">



		<script type="text/javascript"  src="js/libs/jquery/jquery-1.11.2.js"></script>
  		<script type="text/javascript" src="js/libs/jquery/jquery.blockUI.js"></script>
  		<script type="text/javascript" src="js/libs/jquery/jquery-scrollto.js"></script>

  		<!-- LINEAS NECESARIAS PARA PODER REALIZAR EXPORTACIONES-->

		<!-- 	<script src="//cdn.rawgit.com/rainabba/jquery-table2excel/1.1.0/dist/jquery.table2excel.min.js"></script> -->

		<script src="//cdn.datatables.net/1.10.23/js/jquery.dataTables.min.js"></script>
		<script src="//cdn.datatables.net/buttons/1.6.5/js/dataTables.buttons.min.js"></script>
		<script src="//cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
		<script src="//cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
		<script src="//cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
		<script src="//cdn.datatables.net/buttons/1.6.5/js/buttons.html5.min.js"></script>
		<script src="//cdn.datatables.net/buttons/1.6.5/js/buttons.print.min.js"></script>
		<script src="//cdn.datatables.net/1.10.23/css/jquery.dataTables.min.css"></script>
		<script src="//cdn.datatables.net/buttons/1.6.5/css/buttons.dataTables.min.css"></script>


		<!--FIN DE LAS LINEAS NECESARIAS PARA PODER REALIZAR EXPORTACIONES -->


  		<script src="js/libs/uploadify/jquery.uploadify.min.js" type="text/javascript"></script>
		<link rel="stylesheet" type="text/css" href="js/libs/uploadify/uploadify.css">

		<script src="js/libs/prettyPhoto/jquery.prettyPhoto.js" type="text/javascript"></script>
		<link  href="js/libs/prettyPhoto/prettyPhoto.css" rel="stylesheet" type="text/css">
	<!--<script type="text/javascript" src="http://192.168.1.250:3000/socket.io/socket.io.js"></script>-->
		
	

  		<style type="text/css">
  			.divider-full-bleed{
  				margin-top: -15px;
  			}

  			.titulo{
			    font-size: 38px;
			    font-style: italic;
			    color: #ababab;
			    text-shadow: -1px -1px 0px #101010, 1px 1px 0px #ffffff;
			    text-align: center;
				margin-bottom:20px;
			  }

			.panel-close{    
			    float: right;
			    margin-right: 17px;
			    font-size: 28px;
			    cursor: pointer;
			 }
  		</style>


	</head>
	<body class="menubar-hoverable header-fixed menubar-first full-content ">

		<!-- BEGIN HEADER-->
		<header id="header" >
			<div class="headerbar">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="headerbar-left">
					<ul class="header-nav header-nav-options">
						<li class="header-nav-brand" >
							<div class="brand-holder">
								<a>
									<span id="text" class="text-lg text-bold text-primary">UMG </span>
								</a>
							</div>
						</li>
						<li>
							<a class="btn btn-icon-toggle menubar-toggle" data-toggle="menubar" href="javascript:void(0);">
								<i class="fa fa-bars"></i>
							</a>
						</li>
					</ul>
				</div>
				

				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="headerbar-right">
					
					<ul class="header-nav header-nav-profile">
						<li class="dropdown">
							<a href="javascript:void(0);" data-toggle="dropdown">
								<img src="	img/avatar1.jpg?1403934956" alt="" />
								<span class="profile-info">
									<?php echo $_SESSION["nombre"] ?>
									<small><?php echo $_SESSION["tipousuario"] ?></small>
								</span>
							</a>
							<ul class="dropdown-menu animation-dock">
								<li><a href="index.php?a=logout"><i class="fa fa-fw fa-power-off text-info"></i> Cerrar Session</a></li>
							</ul><!--end .dropdown-menu -->
						</li><!--end .dropdown -->
					</ul><!--end .header-nav-profile -->
					
				</div><!--end #header-navbar-collapse -->
			</div>
		</header>
		<!-- END HEADER-->

		<!-- BEGIN BASE-->
		<div id="base">

			<!-- BEGIN MENUBAR-->
			<div id="menubar" class="menubar-inverse">
				<div class="menubar-fixed-panel">
					<div>
						<a class="btn btn-icon-toggle btn-default menubar-toggle" data-toggle="menubar" href="javascript:void(0);">
							<i class="fa fa-bars"></i>
						</a>
					</div>
					<div class="expanded">
						<!--<a href="../../html/dashboards/dashboard.html">-->
							<span class="text-lg text-bold text-primary "></span>
						<!--</a>-->
								
					</div>
				</div>
				<div class="menubar-scroll-panel">
					<ul id="main-menu" class="gui-controls">

					<!-- BEGIN MAIN MENU -->

					<?php 
			        require_once("funciones/classSQL.php");
			        $conexion = new conexion();			        

					
					if($conexion->permisos($_SESSION['idtipousuario'],"2","acceso")){
						echo"<li>
							<a id='menu-usuarios' href='#/usuarios' >
								<div class='gui-icon'><i class='fa fa-user fa-lg'></i></div>
								<span class='title'> USUARIOS</span>
							</a>
						</li>";
					}

					if($conexion->permisos($_SESSION['idtipousuario'],"2","acceso")){
						echo"<li>
							<a id='menu-permisos' href='#/permisos' >
								<div class='gui-icon'><i class='fa fa-key fa-lg'></i></div>
								<span class='title'> ACCESOS</span>
							</a>
						</li>";
					}


					

					if($conexion->permisos($_SESSION['idtipousuario'],"3","acceso")){
						echo"<li>
							<a id='menu-proveedores' href='#/proveedores' >
								<div class='gui-icon'><i class='fa fa-users fa-lg'></i></div>
								<span class='title'> PROVEEDORES</span>
							</a>
						</li>";
					}

					if($conexion->permisos($_SESSION['idtipousuario'],"4","acceso")){
						echo"<li>
							<a id='menu-productos' href='#/productos' >
								<div class='gui-icon'><i class='fa fa-shopping-basket fa-lg'></i></div>
								<span class='title'> PRODUCTOS</span>
							</a>
						</li>";
					}

					if($conexion->permisos($_SESSION['idtipousuario'],"5","acceso")){
						echo"<li>
							<a id='menu-clientes' href='#/clientes' >
								<div class='gui-icon'><i class='fa fa-address-book fa-lg'></i></div>
								<span class='title'> CLIENTES</span>
							</a>
						</li>";
					}


					if($conexion->permisos($_SESSION['idtipousuario'],"6","acceso")){
						echo"<li>
							<a id='menu-ventas' href='#/ventas' >
								<div class='gui-icon'><i class='fa fa-shopping-cart fa-lg'></i></div>
								<span class='title'> VENTAS</span>
							</a>
						</li>";
					}



					if($conexion->permisos($_SESSION['idtipousuario'],"7","acceso")){
			            echo"<li>
							<a id='menu-repProductos' href='#/repProductos' >
								<div class='gui-icon'><i class='fa fa-cog fa-lg'></i></div>
								<span class='title'> Rep. Productos</span>
							</a>
						</li>";
						
			         }

					 if($conexion->permisos($_SESSION['idtipousuario'],"7","acceso")){
			            echo"<li>
							<a id='menu-repVentas' href='#/repVentas' >
								<div class='gui-icon'><i class='fa fa-cog fa-lg'></i></div>
								<span class='title'> Rep. Ventas </span>
							</a>
						</li>";
						
			         }

					 if($conexion->permisos($_SESSION['idtipousuario'],"7","acceso")){
			            echo"<li>
							<a id='menu-repProveedores' href='#/repProveedores' >
								<div class='gui-icon'><i class='fa fa-cog fa-lg'></i></div>
								<span class='title'> Rep. Proveedores</span>
							</a>
						</li>";
						
			         }
					

					?>




					</ul><!--end .main-menu -->
					<!-- END MAIN MENU -->

					<div class="menubar-foot-panel">
						<small class="no-linebreak hidden-folded">
							<span class="opacity-75">Copyright &copy; 2022</span> 
						</small>
					</div>
				</div><!--end .menubar-scroll-panel-->
			</div><!--end #menubar-->
			<!-- END MENUBAR -->

			<!-- BEGIN CONTENT-->
			<div id="content" class="page-wrapper">
				
			</div><!--end #content-->
			<!-- END CONTENT -->
	

						
			<script type="text/javascript">
			$(".menubar-toggle").on("click",function(){
				$('body').addClass('menubar-visible');
			});

			function bloquearPantalla(mensaje) { 
			$.blockUI({ 
				css: { 
				border: 'none', 
				padding: '15px',          
				backgroundColor:'transparent', 
				'-webkit-border-radius': '10px', 
				'-moz-border-radius': '10px', 
				color: '#fff' 
				},
				message: "<h1>"+mensaje+"</h1>",
			});                             
			}

			function desbloquearPantalla()  {
				setTimeout($.unblockUI, 500); 
			}
			</script>		