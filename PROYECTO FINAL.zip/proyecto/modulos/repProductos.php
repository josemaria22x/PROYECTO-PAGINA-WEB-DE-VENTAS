<?php
session_start();
require_once("../funciones/classSQL.php");
$conexion = new conexion();
if($conexion->permisos($_SESSION['idtipousuario'],"7","acceso"))
{
?>

<section>
  <div class="section-body">
    <div class="pageheader">      
        <h2 class="titulo title-1"> Productos más vendidos por año y mes  </h2> 
    </div>

    <div class="pageheader">
      <form class="form">
        <div class="row">
            <div class="col-sm-6 col-md-1"></div>
            
           
            <div class="col-sm-4">
              <div class="form-group">
                <div class="input-group date" >
                  <div class="input-group-content">
                    <input type="text" class="form-control" id="fechainicio" name="fechainicio" value=<?php echo date("d-m-Y") ?>   readonly style="cursor: pointer;">
                    <label>Fecha Inicio</label>
                  </div>
                  <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                </div>
              </div>
            </div>

            <div class="col-sm-4">
              <div class="form-group">
                <div class="input-group date" >
                  <div class="input-group-content">
                    <input type="text" class="form-control" id="fechafin" name="fechafin" value=<?php echo date("d-m-Y") ?>  readonly style="cursor: pointer;" >
                    <label>Fecha Fin</label>
                  </div>
                  <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                </div>
              </div>
            </div>

          
            <div class="col-sm-2">
              <a id="btnMostrarReporte" style="margin-top: 18px;" class="btn btn-primary"> Mostrar</a>
            </div>

            <div class="col-sm-6 col-md-1"></div>


        </div>
      </form>
    </div>

  </div>
  
  <br>

    <div class="card">
      <div class="contentpanel">
        <div class="panel panel-default">

          <div class="card-body">
            <div  class="custom-table table-responsive table--no-card m-b-30">
                <div  id="divTablaVentas" class="table-responsive ">
                
                </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  

  </div><!--end .section-body -->
</section>
  
<?php
}
?>


<script type="text/javascript">


  
  $(document).ready(function() {
    var iniciado = 0;
    $(".date").datetimepicker({ pickTime: false, format: 'DD-MM-YYYY' }); 

    $("#btnMostrarReporte").on("click",mostrarReporte);
    mostrarReporte();
    function mostrarReporte() {
      bloquearPantalla("Espere por favor");
      var tabla = 
      "<table class='table order-column hover' id='tablaRepVentas'>"+
        "<thead>"+
          "<tr> "+
             "<th>No.</th>"+             
             "<th>Fecha de venta</th>"+
             "<th>Nombre del producto</th>"+
             "<th>Precio compra</th>"+
             "<th>Cantidad vendida</th>"+          
          "</tr>"+
        "</thead>"+
        "<tbody></tbody>"+
      "</table>";
      $("#divTablaVentas").html(tabla);
      

      $.post("funciones/ws_productos.php", { accion: "reporteventas" , fechainicio : $("#fechainicio").val() , fechafin : $("#fechafin").val() }, function(data) {
        if(data.resultado)
          {

              $.each(data.ventas,function(key,value) {
              
                $("<tr></tr>")
                  .append( "<td>" + (key + 1) + "</td>" )
                  .append( "<td>" + value["fechahora"] + "</td>" )
                  .append( "<td>" + value["nombre"] + "</td>" )
                  .append( "<td>" + value["preciocompra"] + "</td>" )
                  .append( "<td>" + value["cantidad"] + "</td>" )
                  .appendTo("#tablaRepVentas > tbody");
              });

              $("#tablaRepVentas a").tooltip();             
              $('#tablaRepVentas').DataTable();               
            desbloquearPantalla();
               
          }
          else{
            toastr.warning(data.mensaje,"Info");
            desbloquearPantalla();
          }
      }, "json")
      .fail(function()
      {
          toastr.error("no se pudo conectar al servidor", "Error Conexión");
          desbloquearPantalla();
      });

    }

  });
</script>