<?php
session_start();
require_once("../funciones/classSQL.php");
$conexion = new conexion();
if($conexion->permisos($_SESSION['idtipousuario'],"7","acceso"))
{
?>

<section>
  <div class="section-body">
    <div class="pageheader">      
        <h2 class="titulo title-1"> Total de ventas por mes y por año  </h2> 
    </div>

    <div class="pageheader">
      <form class="form">
        <div class="row">
            <div class="col-sm-6 col-md-1"></div>
            
           
            <div class="col-sm-4">
              <div class="form-group">
                <div class="input-group date" >
                  <div class="input-group-content">
                    <input type="text" class="form-control" id="fechainicio" name="fechainicio" value=<?php echo date("d-m-Y") ?>   readonly style="cursor: pointer;">
                    <label>Fecha Inicio</label>
                  </div>
                  <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                </div>
              </div>
            </div>

            <div class="col-sm-4">
              <div class="form-group">
                <div class="input-group date" >
                  <div class="input-group-content">
                    <input type="text" class="form-control" id="fechafin" name="fechafin" value=<?php echo date("d-m-Y") ?>  readonly style="cursor: pointer;" >
                    <label>Fecha Fin</label>
                  </div>
                  <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                </div>
              </div>
            </div>

          
            <div class="col-sm-2">
              <a id="btnMostrarReporte" style="margin-top: 18px;" class="btn btn-primary"> Mostrar</a>
            </div>

            <div class="col-sm-6 col-md-1"></div>


        </div>
      </form>
    </div>

  </div>
  
  <br>

    <div class="card">
      <div class="contentpanel">
        <div class="panel panel-default">

          <div class="card-body">
            <div  class="custom-table table-responsive table--no-card m-b-30">
                <div  id="divTablaVentas" class="table-responsive ">
                
                </div>
            </div>
          </div>
        </div>
      </div>
    </div>


    
    <br><br>




      <div id="divTablaDetalle" class="contentpanel" style="display:none;">
        <div class="card">

          <div class="panel panel-default">    
            <div class="card-body">
              <div  id="divTablaDetalleVentas" class="table-responsive " ></div>
            </div>
          </div>

        </div>
      </div>
  

  </div><!--end .section-body -->
</section>
  
<?php
}
?>


<script type="text/javascript">


  
  $(document).ready(function() {
    var iniciado = 0;
    $(".date").datetimepicker({ pickTime: false, format: 'DD-MM-YYYY' }); 

    $("#btnMostrarReporte").on("click",mostrarReporte);
    mostrarReporte();
    function mostrarReporte() {
      bloquearPantalla("Espere por favor");
      var tabla = 
      "<table class='table order-column hover' id='tablaRepVentas'>"+
        "<thead>"+
          "<tr> "+
             "<th>No.</th>"+             
             "<th>Fecha y hora</th>"+
             "<th>Total de venta</th>"+     
             "<th></th>"+     
          "</tr>"+
        "</thead>"+
        "<tbody></tbody>"+
      "</table>";
      $("#divTablaVentas").html(tabla);


      var btnEliminar = "";

      

      $.post("funciones/ws_productos.php", { accion: "reporteventastotales" , fechainicio : $("#fechainicio").val() , fechafin : $("#fechafin").val() }, function(data) {
        if(data.resultado)
          {

              $.each(data.ventas,function(key,value) {

                btnEliminar = " <a style='cursor:pointer'  class='item' href='#' title='Ver detalle'> <i class='fa fa-eye fa-lg'></i></a>";

              
                $("<tr></tr>")
                  .append( "<td>" + (key + 1) + "</td>" )
                  .append( "<td>" + value["fechahora"] + "</td>" )
                  .append( "<td>" + value["totalventa"] + "</td>" )
                  .append( $("<td></td>")
                    .append( $("<div class='table-data-feature'></div>")

                        .append( $(btnEliminar)
                            .on("click",{ id:value["id"] } , mostrarDetalleVentas) ) 
                    ))
                  .appendTo("#tablaRepVentas > tbody");
              });

              $("#tablaRepVentas a").tooltip();             
              $('#tablaRepVentas').DataTable();               
            desbloquearPantalla();
               
          }
          else{
            toastr.warning(data.mensaje,"Info");
            desbloquearPantalla();
          }
      }, "json")
      .fail(function()
      {
          toastr.error("no se pudo conectar al servidor", "Error Conexión");
          desbloquearPantalla();
      });

    }


    function mostrarDetalleVentas (e) {
      e.preventDefault();
      
      $("#divTablaDetalle").fadeIn("slow");
      $("#tablaDetalleVentas  tbody tr").remove();

      $.post("funciones/ws_productos.php", { accion: "detalleVenta" , id : e.data.id}, function(data) {
        if(data.resultado)
          { 
            var tabla =
            "<h3 id='tituloModulos' class='tituloH3'></h3><br>"+
            "<table id='tablaDetalleVentas' class='table order-column hover' >"+
              "<thead>"+
                "<tr>  "+
                   "<th>No.</th>"+
                   "<th>Nombre producto</th>"+
                   "<th>Precio compra</th>"+
                   "<th>Precio venta</th>"+
                "</tr>"+
              "</thead>"+
              "<tbody></tbody>"+
            "</table>";
            $("#divTablaDetalleVentas").html(tabla);

            $.each(data.ventas,function(key,value) {
              $("#tituloModulos").html("Detalle de venta");

              $("<tr></tr>")
                .append( "<td>" + (key + 1) + "</td>" )
                .append( "<td>" + value["nombre"] + "</td>" )                
                .append( "<td>" + value["preciocompra"] + "</td>" )                
                .append( "<td>" + value["precioventa"] + "</td>" )                
                .appendTo("#tablaDetalleVentas > tbody");
            });

               
                $('#tablaDetalleVentas').ScrollTo();

          }
          else{
            toastr.warning(data.mensaje,"Info");
          }
      }, "json")
      .fail(function()
      {
          toastr.error("no se pudo conectar al servidor", "Error Conexión");
      });
    }


  });
</script>