<?php
session_start();
require_once("../funciones/classSQL.php");
$conexion = new conexion();
if($conexion->permisos($_SESSION['idtipousuario'],"4","Acceso"))
{
?>
  


<section>
  <div class="section-body">
    <div class="pageheader">      
        <h2 class="titulo"> Categorias </h2> 
    </div>

    

    

    <div class="card">

      <div class="card-header">
        <div class="overview-wrap">
          

          <div class="panel-heading">      
          <a href="#/productos" class="btn btn-warning btn-lg">Productos</a>
          
          <?php if($conexion->permisos($_SESSION['idtipousuario'],"4","Crear")) { ?>
            <a id="btnNuevoCategoria" data-toggle="modal" class="btn btn-primary btn-lg">Nueva Categoria</a>
          <?php } ?>
            
          </div>


        </div>
      </div>

      <div class="contentpanel">
        <div class="panel panel-default">

          <div class="card-body">
            <div  class="custom-table table-responsive table--no-card m-b-30">
              <table id="tablaCategorias" class="table table-borderless table-data3 table-earning" >
              
                <thead>
                  <tr>  
                    <th>No.</th>
                    <th>DESCRIPCION</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody></tbody>
                
              </table>
            </div>
          </div>
        </div>
      </div>

    </div>

    <div id="divTablaDetalle" class="contentpanel" style="display:none; width:75%">
      <h2 class="h2title"><i class="fa fa-table"></i> S U B - C A T E G O R I A S </h2>
      <div class="panel panel-default">    
        <div id="divTablaSubCategorias" class="panel-body"></div>
      </div>
    </div>

    <div id="divNuevoCategoria" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog">
        <form id='formNuevoCategoria' class="form form-validate"  role="form"   method="post" >
          <div class="modal-content  panel panel-primary">
              <div class="card-head style-primary">
                <header>Nueva Categoria</header>
                  <a class="panel-close" data-dismiss="modal" aria-hidden="true">×</a>
              </div>
              <div class="card-body">

                  <div class="form-group floating-label">
                    <input type="text" class="form-control" id="descripcion" name="descripcion" required >
                    <label for="descripcion">Descripción:</label>
                  </div>

              </div> 

                <div class="modal-footer">
                    <div class="response"></div>
                    <button type="button" id="btnGuardarNuevoCategoria" class="btn btn-primary">Guardar</button>
                    <button type="button" id="btnCancelarNuevoCategoria" class="btn btn-default" data-dismiss="modal">Cancelar</button>
                </div>
          </div>
        </form>
      </div>
    </div>

    <div id="divEditarCategorias" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog">
        <form id='formEditarCategorias' class="form form-validate"  role="form"   method="post" >
          <div class="modal-content  panel panel-warning">
              <div class="card-head style-warning">
                <header>Editar Categoria</header>
                  <a class="panel-close" data-dismiss="modal" aria-hidden="true">×</a>
              </div>
              <div class="card-body">

                  <div class="form-group floating-label">
                    <input type="text" class="form-control" id="descripcion" name="descripcion" required >
                    <label for="descripcion">Descripción:</label>
                    <input type="hidden" class="form-control input-md required" name="id" id="id" />
                  </div>

              </div>
                <div class="modal-footer">
                    <div class="response"></div>
                    <button type="button" id="btnGuardarEditarCategorias" class="btn btn-warning">Guardar</button>
                    <button type="button" id="btnCancelarEditarCategorias" class="btn btn-default" data-dismiss="modal">Cancelar</button>
                </div>
          </div>
        </form>
      </div>
    </div>

    <div id="divEliminarCategoria" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog">
          <div class="modal-content  panel panel-danger">
                <div class="card-head style-danger">
                  <header>Eliminar Categoria</header>
                    <a class="panel-close" data-dismiss="modal" aria-hidden="true">×</a>
                </div>
                <div class="card-body">
                    <div class="form-group floating-label">
                        <input type="hidden" name="idEliminarCategoria" id="idEliminarCategoria" class="form-control" />
                        <h4>¿Desea eliminar el registro?</h4>
                    </div>
                </div> <!-- /.panel-body-->
              <div class="modal-footer">
                  <div class="response"></div>
                  <button type="button" id="btnEliminarCategoria" class="btn btn-danger">Si estoy seguro</button>
                  <button type="button" id="btnCancelarEliminarCategoria" class="btn btn-default" data-dismiss="modal">Cancelar</button>
              </div>
          </div>
      </div>
    </div>


  </div><!--end .section-body -->
</section>
  
<?php
}
?>


<script type="text/javascript">



  $(document).ready(function() {
    
    var Acceso = 0;
    var Crear = 0;
    var Modificar = 0;
    var Eliminar = 0;
    var Consultar = 0;

    verficarPermisos();

    function verficarPermisos () {
        $.post("funciones/ws_usuarios.php", {accion:"consultarPermisos" , idmodulo:"4"} ,function(data)
        {
            if(data.resultado){
                Acceso = data.registros[0]["acceso"];
                Crear = data.registros[0]["crear"];
                Modificar = data.registros[0]["modificar"];
                Eliminar = data.registros[0]["eliminar"];
                Consultar = data.registros[0]["consultar"];
                mostrarCategorias();
            }
            else
              toastr.warning(data.mensaje,"Info");
        }, "json")
        .fail(function()
        {
            toastr.error("no se pudo conectar al servidor", "Error Conexión");
        });
    }
    

       

    function mostrarCategorias() {
      $("#tablaCategorias  tbody tr").remove();
      $.post("funciones/ws_categorias.php", { accion: "mostrar" }, function(data) {
        if(data.resultado)
          {

            $.each(data.registros,function(key,value) {
              var btnEditar = "";
              var btnEliminar = "";
              var btnSubCategorias = "";

              if (Modificar == 1) {
                btnEditar = "<a style='cursor:pointer' href='#' title='Editar Categoria'><i class='fa fa-edit fa-lg'></i></a>";
              };

              if (Eliminar == 1) {
                btnEliminar = "<a style='cursor:pointer' href='#' title='Eliminar Categoria'> <i class='fa fa-trash fa-lg'></i></a>";
              };

              if (Consultar == 1) {
                btnSubCategorias = "<a style='cursor:pointer' href='#' title='Agregar sub-categorias'> <i class='fa fa-eye fa-lg'></i></a>";
              };


              $("<tr></tr>")
                .append( "<td>" + (key + 1) + "</td>" )
                .append( "<td>" + value["descripcion"] + "</td>" )
                .append( $("<td></td>")
                    .append( $( btnEditar )
                        .on("click", { idcategoria:value["id"] } , editarCategoria) )
                    .append( $( btnEliminar )
                        .on("click", { idcategoria:value["id"] } , eliminarCategoria) )                  
                  )
                .appendTo("#tablaCategorias > tbody");
            });

                $("#tablaCategorias a").tooltip(); 
                
                $('#tablaCategorias').DataTable( {
                    dom: 'T<"clear">lfrtip',
                    sPaginationType: "full_numbers"
                });


          }
          else{
            toastr.warning(data.mensaje,"Info");
          }
      }, "json")
      .fail(function()
      {
          toastr.error("no se pudo conectar al servidor", "Error Conexión");
      });

    }

    







    /****************** MOSTRAR MODAL NUEVO REGISTRO *******************/
    $("#btnNuevoCategoria").on("click",mostrarModalNuevoCategoria);
    
    function mostrarModalNuevoCategoria(e){
      e.preventDefault();
      $("#formNuevoCategoria")[0].reset();
      $("#divNuevoCategoria").modal("show", {backdrop: "static"});
    }

    /****************** GUARDAR DATOS DEL REGISTRO *******************/
    $("#btnGuardarNuevoCategoria").on("click",guardarNuevoCategoria);
    
    function guardarNuevoCategoria(e){
      e.preventDefault();
      if($("#formNuevoCategoria").valid()) {
          $.post("funciones/ws_categorias.php", "accion=nuevo&"+$("#formNuevoCategoria").serialize() ,function(data) {
            if(data.resultado){
                toastr.success(data.mensaje, "Exito");
                $("#divNuevoCategoria").modal("hide");                
                setTimeout(function(){ratPack.refresh();},300);
            }
            else{
                toastr.warning(data.mensaje,"Info");
            }
          }, "json")
          .fail(function() {
            toastr.error("no se pudo conectar al servidor", "Error Conexión");
          });
      }
    }







    /******************  MUESTRA EL FORMULARIO PARA EDITAR LOS REGISTROS *******************/
    function editarCategoria (e) {
        e.preventDefault();
        $.post("funciones/ws_categorias.php", { accion:"mostrar" , id:e.data.idcategoria }, function(data) {
          if(data.resultado)
            {
              $("#formEditarCategorias")[0].reset();
              $("#divEditarCategorias").modal("show", {backdrop: "static"});
              $("#formEditarCategorias input").addClass("dirty");

              $("#formEditarCategorias #id").val(data.registros[0]["id"]);
              $("#formEditarCategorias #descripcion").val(data.registros[0]["descripcion"]);
             }
            else{
              toastr.warning(data.mensaje,"Info");
            }
        }, "json")
        .fail(function()
        {
            toastr.error("no se pudo conectar al servidor", "Error Conexión");
        });
    }


    /****************** MODIFICAR DATOS DEL REGISTRO *******************/
    $("#btnGuardarEditarCategorias").on("click",guardarEditarCategorias);
    
    function guardarEditarCategorias(e){
      e.preventDefault();
      if($("#formEditarCategorias").valid()) {
          $.post("funciones/ws_categorias.php", "accion=editar&"+$("#formEditarCategorias").serialize() ,function(data) {
            if(data.resultado){
                toastr.success(data.mensaje, "Exito");
                $("#divEditarCategorias").modal("hide");
                setTimeout(function(){ratPack.refresh();},300);
            }
            else{
                toastr.warning(data.mensaje,"Info");
            }
          }, "json")
          .fail(function() {
            toastr.error("no se pudo conectar al servidor", "Error Conexión");
          });
      }
    }




    /******************  MUESTRA EL FORMULARIO PARA ELIMINAR LOS REGISTROS *******************/
    function eliminarCategoria (e) {
      e.preventDefault();
      $("#divEliminarCategoria").modal("show", {backdrop: "static"});
      $("#idEliminarCategoria").val(e.data.idcategoria);
    }
    

    /****************** MODIFICAR DATOS DEL REGISTRO *******************/
    $("#btnEliminarCategoria").on("click",guardarEliminarCategoria);
    
    function guardarEliminarCategoria(e){
        e.preventDefault();
        $.post("funciones/ws_categorias.php", { id:$("#idEliminarCategoria").val() , accion:"eliminar" } ,function(data) {
          if(data.resultado){
              toastr.success(data.mensaje, "Exito");
              $("#divEliminarCategoria").modal("hide");
              setTimeout(function(){ratPack.refresh();},300);
          }
          else{
              toastr.warning(data.mensaje,"Info");
          }
        }, "json")
        .fail(function() {
          toastr.error("no se pudo conectar al servidor", "Error Conexión");
        });
    }


  
    

    

  });
</script>