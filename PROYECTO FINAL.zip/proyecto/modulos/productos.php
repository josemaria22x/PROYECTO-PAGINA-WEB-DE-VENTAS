<?php
session_start();
require_once("../funciones/classSQL.php");
$conexion = new conexion();
if($conexion->permisos($_SESSION['idtipousuario'],"4","Acceso"))
{
?>



<section>
  <div class="section-body">
    <div class="pageheader">      
      <h2 class="titulo title-1"> Productos </h2> 
    </div>

    
    
    <div class="card">

      <div class="card-header">
        <div class="overview-wrap">
          

          <div class="panel-heading">      
          
          <a id="btnNuevoProducto" data-toggle="modal" class="btn btn-primary btn-lg">Nuevo Producto</a>
          <a href="#/categorias" class="btn btn-success btn-lg">Categorias</a>
            
          </div>


        </div>
      </div>

      <div class="contentpanel">
        <div class="panel panel-default">

          <div class="card-body">
            <div  class="custom-table table-responsive table--no-card m-b-30">
              <table id="tablaProductos" class="table table-borderless table-data3 table-earning" >
              <thead>
                <tr>  
                   <th>No.</th>
                   <th>CATEGORIA</th>
                   <th>NOMBRE</th>
                   <th>COD</th>
                   <th>P.CTO</th>
                   <th>P.VTA</th>                   
                   <th>MIN</th>
                   <th>MAX</th>
                   <!--<th>VENCIMIENTO</th>-->
                   <th></th>
                </tr>
              </thead>
              <tbody></tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

    </div>




    <div id="divNuevoProducto" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog">
        <form id='formNuevoProducto' class="form form-validate"  role="form"   method="post" >
          <div class="modal-content  panel panel-primary">
              
            <div class="card-head style-primary">
              <header>Nuevo Producto</header>
                <a class="panel-close" data-dismiss="modal" aria-hidden="true">×</a>
            </div>
            <div class="card-body">

              <input type="hidden" class="form-control" id="unidadmedida" name="unidadmedida"  value="UNIDAD" >
              <input type="hidden" class="form-control" id="preciocompratotal" name="preciocompratotal"  value="0" >
              <input type="hidden" class="form-control" id="divisionunidad" name="divisionunidad"  value="UNIDAD" >
              <input type="hidden" class="form-control" id="cantidaddivision" name="cantidaddivision" value="1">

              <div class="form-group floating-label">
                <select class="form-control select2-list dirty" id="idcategoria" name="idcategoria" placeholder="Seleccionar" >
                </select><div class="form-control-line"></div>
                <label for="idcategoria">Categoria: </label>
              </div>

              <div class="form-group floating-label">
                <select class="form-control select2-list dirty" id="idproveedor" name="idproveedor" placeholder="Seleccionar" >
                </select><div class="form-control-line"></div>
                <label for="idproveedor">Proveedor: </label>
              </div>

              <div class="form-group floating-label">
                <input type="text" class="form-control" id="nombre" name="nombre" required >
                <label for="nombre">Nombre:</label>
              </div>

              <div class="form-group floating-label">
                <input type="text" class="form-control" id="codigo" name="codigo" required >
                <label for="codigo">Código:</label>
              </div>

              <div class="form-group floating-label">
                <input type="number" class="form-control" id="preciocompra" name="preciocompra" required >
                <label for="preciocompra">Precio Compra:</label>
              </div>

              <div class="form-group floating-label">
                <input type="number" class="form-control" id="precioventa" name="precioventa" required >
                <label for="precioventa">Precio Venta:</label>
              </div>

              <div class="form-group floating-label">
                <input type="number" class="form-control" id="existenciaminima" name="existenciaminima" value="0" required >
                <label for="existenciaminima">Existencia Minima:</label>
              </div>

              <div class="form-group floating-label">
                <input type="number" class="form-control" id="existenciamaxima" name="existenciamaxima" value="0" required >
                <label for="existenciamaxima">Existencia Maxima:</label>
              </div>


            </div> <!-- /.modal-body-->
                <div class="modal-footer">
                    <div class="response"></div>
                    <button type="button" id="btnGuardarNuevoProducto" class="btn btn-primary">Guardar</button>
                    <button type="button" id="btnCancelarNuevoProducto" class="btn btn-default" data-dismiss="modal">Cancelar</button>
                </div>
          </div><!-- /.modal-content -->
        </form>
      </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->


    <div id="divEditarProducto" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog">
        <form id='formEditarProducto' class="form form-validate"  role="form"   method="post" >
          <div class="modal-content  panel panel-warning">
            <div class="card-head style-warning">
              <header>Editar Producto</header>
                <a class="panel-close" data-dismiss="modal" aria-hidden="true">×</a>
            </div>
            <div class="card-body">

                <input type="hidden" class="form-control input-md required" name="id" id="id" /> 
                <input type="hidden" class="form-control" id="unidadmedida" name="unidadmedida"  value="UNIDAD" >
                <input type="hidden" class="form-control" id="preciocompratotal" name="preciocompratotal"  value="0" >
                <input type="hidden" class="form-control" id="divisionunidad" name="divisionunidad"  value="UNIDAD" >
                <input type="hidden" class="form-control" id="cantidaddivision" name="cantidaddivision" value="1">
                
              <div class="form-group floating-label">
                <select class="form-control select2-list dirty" id="idcategoria" name="idcategoria" placeholder="Seleccionar" >                          
                </select><div class="form-control-line"></div>
                <label for="idcategoria">Categoria: </label>
              </div>

              <div class="form-group floating-label">
                <select class="form-control select2-list dirty" id="idproveedor" name="idproveedor" placeholder="Seleccionar" >
                </select><div class="form-control-line"></div>
                <label for="idproveedor">Proveedor: </label>
              </div>

              <div class="form-group floating-label">
                <input type="text" class="form-control" id="nombre" name="nombre" required >
                <label for="nombre">Nombre:</label>
              </div>

              <div class="form-group floating-label">
                <input type="text" class="form-control" id="codigo" name="codigo" required >
                <label for="codigo">Código:</label>
              </div>

              <div class="form-group floating-label">
                <input type="number" class="form-control" id="preciocompra" name="preciocompra" required >
                <label for="preciocompra">Precio Compra:</label>
              </div>

              <div class="form-group floating-label">
                <input type="number" class="form-control" id="precioventa" name="precioventa" required >
                <label for="precioventa">Precio Venta:</label>
              </div>

              <div class="form-group floating-label">
                <input type="number" class="form-control" id="existenciaminima" name="existenciaminima"  required >
                <label for="existenciaminima">Existencia Minima:</label>
              </div>

              <div class="form-group floating-label">
                <input type="number" class="form-control" id="existenciamaxima" name="existenciamaxima"  required >
                <label for="existenciamaxima">Existencia Maxima:</label>
              </div>

              
             
            </div> <!-- /.modal-body-->

                <div class="modal-footer">
                    <div class="response"></div>
                    <button type="button" id="btnGuardarEditarProducto" class="btn btn-warning">Guardar</button>
                    <button type="button" id="btnCancelarEditarProducto" class="btn btn-default" data-dismiss="modal">Cancelar</button>
                </div>
          </div><!-- /.modal-content -->
        </form>  
      </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->


    <div id="divEliminarProducto" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog">
          <div class="modal-content  panel panel-danger">
                <div class="card-head style-danger">
                  <header>Eliminar Producto</header>
                    <a class="panel-close" data-dismiss="modal" aria-hidden="true">×</a>
                </div>
                <div class="card-body">
                    <div class="form-group floating-label">
                        <input type="hidden" name="ideliminarproducto" id="ideliminarproducto" class="form-control" />
                        <h4>¿Desea eliminar el registro?</h4>
                    </div>
                </div> <!-- /.panel-body-->
              <div class="modal-footer">
                  <div class="response"></div>
                  <button type="button" id="btnEliminarProducto" class="btn btn-danger">Si estoy seguro</button>
                  <button type="button" id="btnCancelarEliminarProducto" class="btn btn-default" data-dismiss="modal">Cancelar</button>
              </div>
          </div>
      </div>
    </div>


    
    
  </div><!--end .section-body -->
</section>



<?php  
}
?>



<script type="text/javascript">


  
  $(document).ready(function() {


    
    var Acceso = 0;
    var Crear = 0;
    var Modificar = 0;
    var Eliminar = 0;
    var Consultar = 0;

    $(".date").datetimepicker({ pickTime: false ,   format: 'DD/MM/YYYY'});


    verficarPermisos();

    function verficarPermisos () {
        $.post("funciones/ws_usuarios.php", {accion:"consultarPermisos" , idmodulo:"4"} ,function(data)
        {
            if(data.resultado){
                Acceso = data.registros[0]["acceso"];
                Crear = data.registros[0]["crear"];
                Modificar = data.registros[0]["modificar"];
                Eliminar = data.registros[0]["eliminar"];
                Consultar = data.registros[0]["consultar"];
                categorias();
                proveedores();
                mostrarProductos();
            }
            else
              toastr.warning(data.mensaje,"Info");
        }, "json")
        .fail(function()
        {
            toastr.error("no se pudo conectar al servidor", "Error Conexión");
        });
    }


    function categorias() {
        $.post("funciones/ws_categorias.php", {accion:"mostrar"} ,function(data)
        {
            $("#formNuevoProducto #idcategoria").html('');
            $("#formEditarProducto #idcategoria").html('');
            if(data.resultado){
                  $("#formNuevoProducto #idcategoria").append("<option value='' ></option>");
                  $("#formEditarProducto #idcategoria").append("<option value='' ></option>");
                $.each(data.registros,function(key,value) {
                    $("#formNuevoProducto #idcategoria").append("<option value="+value["id"]+" >"+value["descripcion"]+"</option>");
                    $("#formEditarProducto #idcategoria").append("<option value="+value["id"]+" >"+value["descripcion"]+"</option>");
                });

                /****** MOSTRAR SELECT ********/
                $(".select2-list").select2({ allowClear: true });
            }
            else
              toastr.warning(data.mensaje,"Info");
        }, "json")
        .fail(function()
        {
            toastr.error("no se pudo conectar al servidor", "Error Conexión");
        });
    }

    function proveedores() {
        $.post("funciones/ws_proveedores.php", {accion:"mostrar"} ,function(data)
        {
            $("#formNuevoProducto #idproveedor").html('');
            $("#formEditarProducto #idproveedor").html('');
            if(data.resultado){
                  $("#formNuevoProducto #idproveedor").append("<option value='' ></option>");
                  $("#formEditarProducto #idproveedor").append("<option value='' ></option>");
                $.each(data.registros,function(key,value) {
                    $("#formNuevoProducto #idproveedor").append("<option value="+value["id"]+" >"+value["nombreproveedor"]+"</option>");
                    $("#formEditarProducto #idproveedor").append("<option value="+value["id"]+" >"+value["nombreproveedor"]+"</option>");
                });

                /****** MOSTRAR SELECT ********/
                $(".select2-list").select2({ allowClear: true });
            }
            else
              toastr.warning(data.mensaje,"Info");
        }, "json")
        .fail(function()
        {
            toastr.error("no se pudo conectar al servidor", "Error Conexión");
        });
    }

    
    function mostrarProductos () {
      $("#tablaProductos  tbody tr").remove();
      bloquearPantalla("Espere por favor");
      $.post("funciones/ws_productos.php", { accion: "mostrar" , opcion:'0' }, function(registros) {
        if(registros.resultado)
          {


            $.each(registros.data,function(key,value) {
              
              var btnEditar = "";
              var btnEliminar = "";
              var btnConsultar = "";

              if (Modificar == 1) {
                btnEditar = "<a style='cursor:pointer' href='#' title='Editar Producto'><i class='fa fa-edit fa-lg'></i></a>";
              };

              if (Eliminar == 1) {
                btnEliminar = "<a style='cursor:pointer' href='#' title='Eliminar Producto'> <i class='fa fa-trash fa-lg'></i></a>";
              };

              if (Consultar == 1) {
                  btnConsultar = "<a style='cursor:pointer' href='#' title='Sucursales'> <i class='fa fa-map-marker fa-lg'></i></a>";
              };

              $("<tr></tr>")
                .append( "<td>" + (key + 1) + "</td>" )
                .append( "<td>" + value["categoria"] + "</td>" )
                .append( "<td>" + value["nombre"] + "</td>" )
                .append( "<td>" + value["codigo"] + "</td>" )
                .append( "<td>Q." + value["preciocompra"] + "</td>" )
                .append( "<td>Q." + value["precioventa"] + "</td>" )                
                .append( "<td>" + value["existenciaminima"] + "</td>" )
                .append( "<td>" + value["existenciamaxima"] + "</td>" )
                //.append( "<td>" + value["fecha_vencimiento"] + "</td>" )
                .append( $("<td style='width: 100px;'></td>")
                    .append( $( btnEditar )
                        .on("click", { idproducto:value["id"] } , editarProducto) )
                    .append( $( btnEliminar )
                        .on("click", { idproducto:value["id"] } , eliminarProducto) )
                        
                  )
                .appendTo("#tablaProductos > tbody");
            });

            
                $("#tablaProductos a").tooltip(); 
                $("#tablaProductos").DataTable( {
                    dom: 'T<"clear">lfrtip',
                    sPaginationType: "full_numbers"
                } );

                desbloquearPantalla();
          }
          else{
            //console.log(registros.datasql);

            toastr.warning(registros.mensaje,"Info");
            desbloquearPantalla();
          }
      }, "json")
      .fail(function()
      {
          toastr.error("no se pudo conectar al servidor", "Error Conexión");
          desbloquearPantalla();
      });

    }




    /****************** MOSTRAR MODAL NUEVO REGISTRO *******************/
    $("#btnNuevoProducto").on("click",mostrarModalNuevoProducto);
    
    function mostrarModalNuevoProducto(e){
      e.preventDefault();
      $("#formNuevoProducto")[0].reset();
      $("#divNuevoProducto").modal({backdrop: 'static', keyboard: false});
    }

    /****************** GUARDAR DATOS DEL REGISTRO *******************/
    $("#btnGuardarNuevoProducto").on("click",guardarNuevoProducto);
    
    function guardarNuevoProducto(e){
      e.preventDefault();
      if($("#formNuevoProducto").valid()) {
          //console.log($("#formNuevoProducto").serialize());
          $.post("funciones/ws_productos.php", "accion=nuevo&"+$("#formNuevoProducto").serialize() ,function(data) {
            if(data.resultado){
                toastr.success(data.mensaje, "Exito");
                $("#divNuevoProducto").modal("hide");
                setTimeout(function(){ratPack.refresh();},300);
            }
            else{
                toastr.warning(data.mensaje,"Info");
            }
          }, "json")
          .fail(function() {
            toastr.error("no se pudo conectar al servidor", "Error Conexión");
          });
      }
    }







    /******************  MUESTRA EL FORMULARIO PARA EDITAR LOS REGISTROS *******************/
    function editarProducto (e) {
        e.preventDefault();
        $.post("funciones/ws_productos.php", { accion:"mostrar" , id:e.data.idproducto }, function(registros) {
          if(registros.resultado)
            {
              $("#formEditarProducto")[0].reset();
              $("#divEditarProducto").modal({backdrop: 'static', keyboard: false});
              $("#formEditarProducto input").addClass("dirty");
              
              $("#formEditarProducto #id").val(registros.data[0]["id"]);                      
              $("#formEditarProducto #nombre").val(registros.data[0]["nombre"]);
              $("#formEditarProducto #descripcion").val(registros.data[0]["descripcion"]);
              $("#formEditarProducto #codigo").val(registros.data[0]["codigo"]);
              $("#formEditarProducto #existenciaminima").val(registros.data[0]["existenciaminima"]);
              $("#formEditarProducto #existenciamaxima").val(registros.data[0]["existenciamaxima"]);

              $("#formEditarProducto #fechavencimiento").val(registros.data[0]["fecha_vencimiento"]);


              $("#formEditarProducto #ingreso").val(registros.data[0]["ingreso"]);
              $("#formEditarProducto #salida").val(registros.data[0]["salida"]);
              $("#formEditarProducto #existencia").val(registros.data[0]["existencia"]);
              $("#formEditarProducto #preciocompra").val(registros.data[0]["preciocompra"]);
              $("#formEditarProducto #precioventa").val(registros.data[0]["precioventa"]);
              $("#formEditarProducto #preciooferta").val(registros.data[0]["preciooferta"]);
              
              $("#formEditarProducto #idcategoria option[value='"+registros.data[0]["idcategoria"]+"']").attr("selected","selected");
              $(".select2-list").select2({ allowClear: true });

              
              $("#formEditarProducto #idproveedor option[value='"+registros.data[0]["idproveedor"]+"']").attr("selected","selected");
              $("#formEditarProducto #impresion option[value='"+registros.data[0]["impresion"]+"']").attr("selected","selected");
              
              $(".select2-list").select2({ allowClear: true });


            }
            else{
              toastr.warning(registros.mensaje,"Info");
            }
        }, "json")
        .fail(function()
        {
            toastr.error("no se pudo conectar al servidor", "Error Conexión");
        });
    }


    /****************** MODIFICAR DATOS DEL REGISTRO *******************/
    $("#btnGuardarEditarProducto").on("click",guardarEditarProducto);
    function guardarEditarProducto(e){
      e.preventDefault();
      if($("#formEditarProducto").valid()) {
          $.post("funciones/ws_productos.php", "accion=editar&"+$("#formEditarProducto").serialize() ,function(data) {
            if(data.resultado){
                toastr.success(data.mensaje, "Exito");
                $("#divEditarProducto").modal("hide");
                setTimeout(function(){ratPack.refresh();},300);
            }
            else{
                toastr.warning(data.mensaje,"Info");
            }
          }, "json")
          .fail(function() {
            toastr.error("no se pudo conectar al servidor", "Error Conexión");
          });
      }
    }




    /******************  MUESTRA EL FORMULARIO PARA ELIMINAR LOS REGISTROS *******************/
    function eliminarProducto (e) {
      e.preventDefault();
      $("#divEliminarProducto").modal({backdrop: 'static', keyboard: false});
      $("#ideliminarproducto").val(e.data.idproducto);
    }
    

    /****************** MODIFICAR DATOS DEL REGISTRO *******************/
    $("#btnEliminarProducto").on("click",guardarEliminarProducto);
    
    function guardarEliminarProducto(e){
        e.preventDefault();
        $.post("funciones/ws_productos.php", { id:$("#ideliminarproducto").val() , accion:"eliminar" } ,function(data) {
          if(data.resultado){
              toastr.success(data.mensaje, "Exito");
              $("#divEliminarProducto").modal("hide");
              setTimeout(function(){ratPack.refresh();},300);
          }
          else{
              toastr.warning(data.mensaje,"Info");
          }
        }, "json")
        .fail(function() {
          toastr.error("no se pudo conectar al servidor", "Error Conexión");
        });
    }


    

  });
</script>