<?php
session_start();
require_once("../funciones/classSQL.php");
$conexion = new conexion();
if($conexion->permisos($_SESSION['idtipousuario'],"7","acceso"))
{
?>

<section>
  <div class="section-body">
    <div class="pageheader">      
        <h2 class="titulo title-1"> Proveedores y productos  </h2> 
    </div>

  

  </div>
  
  <br>

    <div class="card">
      <div class="contentpanel">
        <div class="panel panel-default">

          <div class="card-body">
            <div  class="custom-table table-responsive table--no-card m-b-30">
                <div  id="divTablaVentas" class="table-responsive ">
                
                </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  

  </div><!--end .section-body -->
</section>
  
<?php
}
?>


<script type="text/javascript">


  
  $(document).ready(function() {
    var iniciado = 0;

    mostrarReporte();
    function mostrarReporte() {
      bloquearPantalla("Espere por favor");
      var tabla = 
      "<table class='table order-column hover' id='tablaRepVentas'>"+
      "<thead>"+
        "<tr>  "+
            "<th>No.</th>"+
            "<th>PROVEEDOR</th>"+
            "<th>Nombre producto</th>"+
            "<th>Precio compra</th>"+
        "</tr>"+
        "</thead>"+
        "<tbody></tbody>"+
      "</table>";
      $("#divTablaVentas").html(tabla);
      

      $.post("funciones/ws_productos.php", { accion: "productosXproveedor" }, function(data) {
        if(data.resultado)
          {

              $.each(data.ventas,function(key,value) {
              
                $("<tr></tr>")
                .append( "<td>" + (key + 1) + "</td>" )
                .append( "<td>" + value["nombreproveedor"] + "</td>" )                
                .append( "<td>" + value["nombre"] + "</td>" )                
                .append( "<td>" + value["preciocompra"] + "</td>" )                
                  .appendTo("#tablaRepVentas > tbody");
              });

              $("#tablaRepVentas a").tooltip();             
              $('#tablaRepVentas').DataTable();               
            desbloquearPantalla();
               
          }
          else{
            toastr.warning(data.mensaje,"Info");
            desbloquearPantalla();
          }
      }, "json")
      .fail(function()
      {
          toastr.error("no se pudo conectar al servidor", "Error Conexión");
          desbloquearPantalla();
      });

    }

  });
</script>