<?php
session_start();
require_once ("../funciones/classSQL.php");
$conexion = new conexion();
if($conexion->permisos($_SESSION['idtipousuario'],"2","acceso"))
{
?>

  
<section>
  <div class="section-body">
    <div class="pageheader">      
        <h2 class="titulo title-1"> Usuarios </h2>
    </div>

    <div class="card">

      <div class="card-header">
        <div class="overview-wrap">
          

          <div class="panel-heading">      
            <?php if($conexion->permisos($_SESSION['idtipousuario'],"2","crear")) { ?>
              <a id="btnNuevoUsuario" data-toggle="modal" class="btn btn-primary btn-lg">Nuevo Usuario</a>
            <?php } ?>
            
          </div>


        </div>
      </div>

      <div class="contentpanel">
        <div class="panel panel-default">

          <div class="card-body">
            <div  class="custom-table table-responsive table--no-card m-b-30">
              <table id="tablaUsuarios" class="table table-borderless table-data3 table-earning" >
                <thead>
                  <tr>  
                    <th>No.</th>
                    <th>TIPO USUARIO</th>
                    <th>AREA</th>
                    <th>USUARIO</th>
                    <th>NOMBRE</th>
                    <th>CLAVE</th>
                    <th>ACTIVO</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody></tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

    </div>


    

    <div id="divNuevoUsuario" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog">
        <form id='formNuevoUsuario' class="form form-validate"  role="form"   method="post" >
          <div class="modal-content  panel panel-primary">
              <div class="card-head style-primary">
                <header>Nuevo Usuario</header>
                  <a class="panel-close" data-dismiss="modal" aria-hidden="true">×</a>
              </div>
              <div class="card-body">

                <div class="form-group floating-label">
                  <select class="form-control select2-list" id="idtipousuario" name="idtipousuario" >                          
                  </select><div class="form-control-line"></div>
                  <label for="idtipousuario">Tipo usuario: </label>
                </div>

                <div class="form-group floating-label">
                  <select class="form-control select2-list" id="idsucursal" name="idsucursal" > 
                    <option value="2"> HABITACIONES</option>
                    <option value="3"> OFICINA</option>
                  </select><div class="form-control-line"></div>
                  <label for="idsucursal">Area de Trabajo: </label>
                </div>

                <div class="form-group floating-label">
                  <input type="text" class="form-control" id="usuario" name="usuario" required >
                  <label for="usuario">Usuario:</label>
                </div>

                <div class="form-group floating-label">
                  <input type="password" class="form-control" id="clave" name="clave" required >
                  <label for="clave">Clave:</label>
                </div>

                <div class="form-group floating-label">
                  <input type="text" class="form-control" id="nombre" name="nombre" required >
                  <label for="nombre">Nombre Usuario:</label>
                </div>

                <div class="form-group floating-label">
                  <div class="col-sm-12">
                    <label class="radio-inline radio-styled radio-primary">
                      <input type="radio" name="activado" id="activado0" value="1" checked ><span>Activo</span>
                    </label>
                    <label style="margin-left: 20px;" class="radio-inline radio-styled radio-primary">
                      <input type="radio" name="activado" id="activado1" value="0"><span>De baja</span>
                    </label>
                  </div><!--end .col -->
                </div>

              </div>
                  <div class="modal-footer">
                      <div class="response"></div>
                      <button type="button" id="btnGuardarNuevoUsuario" class="btn btn-primary">Guardar</button>
                      <button type="button" id="btnCancelarNuevoUsuario" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                  </div>
          </div>
        </form>  
      </div>
    </div>




    <div id="divEditarUsuario" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog">
        <form id='formEditarUsuario' class="form form-validate"  role="form"   method="post" >
          <div class="modal-content  panel panel-warning">
              <div class="card-head style-warning">
                <header>Editar Usuario</header>
                  <a class="panel-close" data-dismiss="modal" aria-hidden="true">×</a>
              </div>
              <div class="card-body">

                <div class="form-group floating-label">
                  <select class="form-control select2-list dirty" id="idtipousuario" name="idtipousuario" >                          
                  </select><div class="form-control-line"></div>
                  <label for="idtipousuario">Tipo usuario: </label>
                </div>

                <div class="form-group floating-label">
                  <select class="form-control select2-list" id="idsucursal" name="idsucursal" > 
                    <option value="2"> HABITACIONES</option>
                    <option value="3"> OFICINA</option>
                  </select><div class="form-control-line"></div>
                  <label for="idsucursal">Area de Trabajo: </label>
                </div>

                <div class="form-group floating-label">
                  <input type="text" class="form-control" id="usuario" name="usuario" required >
                  <input type="hidden" class="form-control" name="idusuario" id="idusuario" />
                  <label for="usuario">Usuario:</label>
                </div>

                <div class="form-group floating-label">
                  <input type="password" class="form-control" id="clave" name="clave" required >
                  <label for="clave">Usuario:</label>
                </div>

                <div class="form-group floating-label">
                  <input type="text" class="form-control" id="nombre" name="nombre" required >
                  <label for="nombre">Nombre Usuario:</label>
                </div>

                <div class="form-group floating-label">
                  <div class="col-sm-12">
                    <label class="radio-inline radio-styled radio-primary">
                      <input type="radio" name="activado" id="activado0" value="1" checked ><span>Activo</span>
                    </label>
                    <label style="margin-left: 20px;" class="radio-inline radio-styled radio-primary">
                      <input type="radio" name="activado" id="activado1" value="0"><span>De baja</span>
                    </label>
                  </div><!--end .col -->
                </div>

              </div>
                  <div class="modal-footer">
                      <div class="response"></div>
                      <button type="button" id="btnGuardarEditarUsuario" class="btn btn-warning">Guardar</button>
                      <button type="button" id="btnCancelarEditarUsuario" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                  </div>
          </div>
        </form>  
      </div>
    </div>



    <div id="divEliminarUsuario" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog">
          <div class="modal-content  panel panel-danger">
                <div class="card-head style-danger">
                  <header>Eliminar Usuario</header>
                    <a class="panel-close" data-dismiss="modal" aria-hidden="true">×</a>
                </div>
                <div class="card-body">
                    <div class="form-group floating-label">
                        <input type="hidden" name="ideliminarusuario" id="ideliminarusuario" class="form-control" />
                        <h4>¿Desea eliminar el registro?</h4>

                        
                    </div>
                </div> <!-- /.panel-body-->
              <div class="modal-footer">
                  <div class="response"></div>
                  <button type="button" id="btnEliminarUsuario" class="btn btn-danger">Si estoy seguro</button>
                  <button type="button" id="btnCancelarEliminarUsuario" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
              </div>
          </div>
      </div>
    </div>





    
  </div><!--end .section-body -->
</section>



<?php 
}
?>


  
<script type="text/javascript">


  $(document).ready(function() {

    var Acceso = 0;
    var Crear = 0;
    var Modificar = 0;
    var Eliminar = 0;
    var Consultar = 0;

    verficarPermisos();

    

    function verficarPermisos () {
        $.post("funciones/ws_usuarios.php", {accion:"consultarPermisos" , idmodulo:"2"} ,function(data)
        {
            if(data.resultado){
                Acceso = data.registros[0]["acceso"];
                Crear = data.registros[0]["crear"];
                Modificar = data.registros[0]["modificar"];
                Eliminar = data.registros[0]["eliminar"];
                Consultar = data.registros[0]["consultar"];
                tipousuarios();
                mostrarUsuarios();
            }
            else
              toastr.warning(data.mensaje,"Info");
        }, "json")
        .fail(function()
        {
            toastr.error("no se pudo conectar al servidor", "Error Conexión");
        });
    }
    
    

    function tipousuarios() {
        $.post("funciones/ws_tipousuarios.php", {accion:"mostrarTU"} ,function(data)
        {
            $("#idtipousuario").html('');
            if(data.resultado){
                $("#formNuevoUsuario #idtipousuario").append("<option value= ></option>");
                $("#formEditarUsuario #idtipousuario").append("<option value= ></option>");
                $.each(data.registros,function(key,value) {
                  $("#formNuevoUsuario #idtipousuario").append("<option value="+value["id"]+" >"+value["descripcion"]+"</option>");
                  $("#formEditarUsuario #idtipousuario").append("<option value="+value["id"]+" >"+value["descripcion"]+"</option>");
                });

                /****** MOSTRAR SELECT ********/
                $(".select2-list").select2({ allowClear: true });
            }
            else
              toastr.warning(data.mensaje,"Info");

            
            
        }, "json")
        .fail(function()
        {
            toastr.error("no se pudo conectar al servidor", "Error Conexión");
        });
    }

    
    function mostrarUsuarios () {
      $("#tablaUsuarios  tbody tr").remove();
      $.post("funciones/ws_usuarios.php", { accion: "mostrar" }, function(data) {
        if(data.resultado)
          {

            var btnEditar = "";
            var btnEliminar = "";
            var btnPermisos = "";

            $.each(data.registros,function(key,value) {
              var activado ="Activado";
              if (value["activado"] == 0) {
                var activado ="Desactivado";
              }

              if (Modificar == 1) {
                btnEditar = " <a style='cursor:pointer; ' class='item' href='#' title='Editar usuario'><i class='fa fa-edit fa-lg '></i></a>";
              };

              if (Eliminar == 1) {
                btnEliminar = " <a style='cursor:pointer'  class='item' href='#' title='Eliminar usuario'> <i class='fa fa-trash fa-lg'></i></a>";
              };

              $("<tr  rel='"+value["id"]+"'></tr>")
                .append( "<td>" + (key + 1) + "</td>" )
                .append( "<td>" + value["tipousuario"] + "</td>" )
                .append( "<td>" + value["sucursal"] + "</td>" )
                .append( "<td>" + value["usuario"] + "</td>" )
                .append( "<td>" + value["nombre"] + "</td>" )
                .append( "<td>" + value["claveUsuario"] + "</td>" )
                .append( "<td>" + activado + "</td>" )
                .append( $("<td></td>")
                .append( $("<div class='table-data-feature'></div>")
                      .append( $(btnEditar)
                          .on("click",{ idusuario:value["id"] } , editarUsuario) )
                      .append( $(btnEliminar)
                          .on("click",{ idusuario:value["id"] } , eliminarUsuario) )  
                    ))
                .appendTo("#tablaUsuarios > tbody");
            });

                $("#tablaUsuarios a").tooltip(); 
                $("#tablaUsuarios").DataTable();

          }
          else{
            toastr.warning(data.mensaje,"Info");
          }
      }, "json")
      .fail(function()
      {
          toastr.error("no se pudo conectar al servidor", "Error Conexión");
      });

    }

    
    /****************** MOSTRAR MODAL NUEVO REGISTRO *******************/
    $("#btnNuevoUsuario").on("click",mostrarModalNuevoUsuario);
    
    function mostrarModalNuevoUsuario(e){

      e.preventDefault();
      $("#formNuevoUsuario")[0].reset();
      $("#formNuevoUsuario input").removeClass("dirty");
      $("#divNuevoUsuario").modal("show", {backdrop: "static"});

    }


    /****************** GUARDAR DATOS DEL REGISTRO *******************/
    $("#btnGuardarNuevoUsuario").on("click",guardarNuevoUsuario);
    function guardarNuevoUsuario(e){
      e.preventDefault();
      if($("#formNuevoUsuario").valid()) {
          //console.log($("#formNuevoUsuario").serialize());
          $.post("funciones/ws_usuarios.php", "accion=nuevo&"+$("#formNuevoUsuario").serialize() ,function(data) {
            if(data.resultado){
                toastr.success(data.mensaje, "Exito");
                $("#divNuevoUsuario").modal("hide");
                setTimeout(function(){ratPack.refresh();},300);
            }
            else{
                toastr.warning(data.mensaje,"Info");
            }
          }, "json")
          .fail(function() {
            toastr.error("no se pudo conectar al servidor", "Error Conexión");
          });
      }
    }

    /******************  MUESTRA EL FORMULARIO PARA EDITAR LOS REGISTROS *******************/
    function editarUsuario (e) {
        e.preventDefault();
        $.post("funciones/ws_usuarios.php", { accion:"mostrar" , id:e.data.idusuario }, function(data) {
          if(data.resultado)
            {
              $("#formEditarUsuario")[0].reset();
              $("#divEditarUsuario").modal("show", {backdrop: "static"});
              $("#formEditarUsuario input").addClass("dirty");

              $("#formEditarUsuario #idusuario").val(data.registros[0]["id"]);                      
              $("#formEditarUsuario #idtipousuario option[value='"+data.registros[0]["idtipousuario"]+"']").attr("selected","selected");
              $(".select2-list").select2({ allowClear: true });
              $("#formEditarUsuario #idsucursal option[value='"+data.registros[0]["idsucursal"]+"']").attr("selected","selected");
              $(".select2-list").select2({ allowClear: true });

              $("#formEditarUsuario #usuario").val(data.registros[0]["usuario"]);
              $("#formEditarUsuario #clave").val(data.registros[0]["clave"]);
              $("#formEditarUsuario #nombre").val(data.registros[0]["nombre"]);
            }
            else{
              toastr.warning(data.mensaje,"Info");
            }
        }, "json")
        .fail(function()
        {
            toastr.error("no se pudo conectar al servidor", "Error Conexión");
        });
    }


    /****************** MODIFICAR DATOS DEL REGISTRO *******************/
    $("#btnGuardarEditarUsuario").on("click",guardarEditarUsuario);
    
    function guardarEditarUsuario(e){
      e.preventDefault();
      if($("#formEditarUsuario").valid()) {
          $.post("funciones/ws_usuarios.php", "accion=editar&"+$("#formEditarUsuario").serialize() ,function(data) {
            if(data.resultado){
                toastr.success(data.mensaje, "Exito");;
                $("#divEditarUsuario").modal("hide");
                setTimeout(function(){ratPack.refresh();},300);
            }
            else{
                toastr.warning(data.mensaje,"Info");
            }
          }, "json")
          .fail(function() {
            toastr.error("no se pudo conectar al servidor", "Error Conexión");
          });
      }
    }




    /******************  MUESTRA EL FORMULARIO PARA ELIMINAR LOS REGISTROS *******************/
    function eliminarUsuario (e) {
      e.preventDefault();
      $("#divEliminarUsuario").modal("show", {backdrop: "static"});
      $("#ideliminarusuario").val(e.data.idusuario);
    }
    

    /****************** MODIFICAR DATOS DEL REGISTRO *******************/
    $("#btnEliminarUsuario").on("click",guardarEliminarUsuario);
    
    function guardarEliminarUsuario(e){
        e.preventDefault();
        $.post("funciones/ws_usuarios.php", { idusuario:$("#ideliminarusuario").val() , accion:"eliminar" } ,function(data) {
          if(data.resultado){
              toastr.success(data.mensaje, "Exito");
              $("#divEliminarUsuario").modal("hide");
              setTimeout(function(){ratPack.refresh();},300);
          }
          else{
              toastr.warning(data.mensaje,"Info");
          }
        }, "json")
        .fail(function() {
          toastr.error("no se pudo conectar al servidor", "Error Conexión");
        });
    }


  });
</script>