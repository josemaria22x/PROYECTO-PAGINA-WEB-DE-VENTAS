<?php
session_start();
require_once("../funciones/classSQL.php");
$conexion = new conexion();
if($conexion->permisos($_SESSION['idtipousuario'],"6","acceso"))
{
?>
  
<section>
  <div class="section-body">

    <div id="divModuloVentas" class="contentpanel" >
      <div class="row"> 
        <div class="col-sm-12">
            <div class="card">              
              <div class="card-body">

                <h3 style="margin-top: 20px;"><i class="fa fa-fw fa-tag"></i> Datos del Cliente</h3>
                <form id="formCliente" class="form floating-label form-validation" role="form" novalidate="novalidate">
                  <div class="row">
                    
                    <input type="hidden" class="form-control" id="idCliente" name="idCliente"  >
                    <input type="hidden" class="form-control" id="idsucursal" name="idsucursal" value=<?php  echo $_SESSION["idsucursal"]; ?> >
                    <div class="col-sm-4" >
                      <div class="form-group">
                        <input type="text" class="form-control" id="nit" name="nit" required >
                        <label for="nit">Rut:</label>
                      </div>
                    </div>
                    <div class="col-sm-4" >
                      <div class="form-group">
                        <input type="text" class="form-control" id="nombre" name="nombre" required >
                        <label for="nombre">Nombre:</label>
                      </div> 
                    </div>
                    
                    <div class="col-sm-4" >
                      <div class="form-group">
                        <input type="text" class="form-control" id="telefono" name="telefono" required >
                        <label for="telefono">Telefono:</label>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>


            <div style="background: #ffffff">
                <div class="row">

                    <div class="col-sm-6">
                    <div class="card">
                        <div style="background: #ff5722; color: #fff; padding: 0px 25px 0px 25px;">
                        <h1 style="display: inline-block; margin: 5px;">Total Q. </h1>
                        <h1 style="display: inline-block; float: right; margin: 5px;" id="txttotalPagar">0.00</h1>
                        <input type="hidden" name="totalPagar" id="totalPagar">
                        </div>
                    </div>
                    </div>

                    <div class="col-sm-6">
                    <button type="button" class="btn btn-block ink-reaction btn-success" id="agregarCobro" style="font-size: 22px;"><i class="fa fa-shopping-cart" ></i> &nbsp; &nbsp; C O B R A R</button>

                    </div>


                </div>
            </div>


            <div class="card">              
              <div class="card-body">
                                    
                <h3 style="margin-top: 20px;"><i class="fa fa-fw fa-tag"></i> Productos
                <span style="color: #f01b0e; background: #fff; cursor: pointer;" class="input-group-addon"><span class="fa fa-search-plus fa-2x" id="btnMostrarProductos"></span></span>

                </h3>
                <div class="row">                  
                    <div class="form-group col-sm-3 has-error has-feedback" style="display:none;">
                      <input type="text" style="padding-left: 35%;" class="form-control" id="cantidad" name="cantidad" value="1"  required >
                      <label for="cantidad">Cantidad:</label>
                    </div>

                    <div class="form-group col-sm-9">
                      <div class="input-group">
                        
                      </div>
                    </div>

                </div>

                <table id="tablaProductoSeleccionado" class="table table-striped no-margin">
                  <thead>
                    <tr style="background: #ff5722; color: #fff;">
                      <th>#</th>
                      <th>CODIGO</th>
                      <th>PRODUCTO</th>
                      <th>CANTIDAD</th>
                      <th>PRECIO</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody></tbody>
                </table><br>
              </div>
            </div>            
        </div>
        
        
      </div>
    </div>


    <div id="divModuloPedidos" class="contentpanel" >
      <div id="divModuloPedidos"  class="contentpanel">
      </div>
    </div>
    

    <div id="divConsultar" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog" style="width: 500px;">
        <form id="formConsultar" class="form floating-label form-validation" role="form" method="post">
          <div class="modal-content  panel panel-primary">
              <div class="card-head style-primary">
                <header>Consulta de Precios</header>
                  <a class="panel-close" data-dismiss="modal" aria-hidden="true">×</a>
              </div>
              <div class="card-body">
                     
                <table id="tablaProductos" class="table table-striped no-margin">
                  <thead>
                    <tr>
                      <th>CODIGO</th>
                      <th>NOMBRE</th>
                      <th>PRECIO</th>
                      <th>EXIS</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody></tbody>
                </table><br>

              </div>
                  
          </div>
        </form>
      </div>
    </div>

  </div>
</section>


<?php } ?>

<style type="text/css">
  .card-body {
      padding: 0px 24px !important;
  }

  .table thead {
    opacity: 1;
  }

  .card-head {
    line-height: 45px;
    min-height: 44px;
  }

  .accionesReservaciones{
    margin-left: -18px;
    margin-right: -18px;
    border-radius: 4px 4px 4px 4px;
    text-align: center;
    padding-top: 6px;
  }
  .accionesReservaciones p{
    font-size: 14px;    
  }

</style>


<script type="text/javascript">


  
  var pedidoConsolidado = Array();
  var pedido = Array();
  var consumido = 0;


  $(document).ready(function() {

    $(".date").datetimepicker({ pickTime: false, format: 'DD-MM-YYYY' });

      var Acceso = 0;
      var Crear = 0;
      var Modificar = 0;
      var Eliminar = 0;
      var Consultar = 0;

      verficarPermisos();
      

      function verficarPermisos () {
        $.post("funciones/ws_usuarios.php", {accion:"consultarPermisos" , idmodulo:"6"} ,function(data)
        {
            if(data.resultado){
                Acceso = data.registros[0]["acceso"];
                Crear = data.registros[0]["crear"];
                Modificar = data.registros[0]["modificar"];
                Eliminar = data.registros[0]["eliminar"];
                Consultar = data.registros[0]["consultar"];
                productos();
            }
            else
              toastr.warning(data.mensaje,"Información");
        }, "json")
        .fail(function()
        {
            toastr.error("no se pudo conectar al servidor", "Error Conexión");
        });
    }


    function productos() {
        var btnSeleccionar = "<a style='cursor:pointer' class='btnSeleccionar' href='#' title='Agregar a la venta'> <i class='fa fa-check fa-lg'></i></a>";
        table = $("#tablaProductos").DataTable( {
                    "destroy":true,
                    "dom": 'T<"clear">lfrtip',
                    "ajax": {
                      "url": "funciones/ws_productos.php",
                      "data" :{
                        accion: "mostrar" , opcion:"todo" 
                      },
                      "type": "POST"
                    },
                    "columns":[
                      {"data":"codigo"},
                      {"data":"nombre"},
                      {"data":"precioventa"},
                      {"data":"existencia"},
                      {
                          "orderable":      false,
                          "data":           null,
                          "defaultContent": btnSeleccionar
                      }
                    ]                
              });


        $("#tablaProductos tbody").on("click", "a.btnSeleccionar", function (e) {
            e.preventDefault();
            var row = table.row( $(this).closest('tr') );
            var fila = table.row( $(this).parents('tr') ).data();
            
            var index = pedido.length;
            
            pedido[index] = new Object();

            pedido[index].idproductoubicacion = fila["idproductoubicacion"];
            pedido[index].idproducto = fila["id"];
            pedido[index].cantidad = parseInt($("#cantidad").val());
            pedido[index].codigo = fila["codigo"];
            pedido[index].nombre = fila["nombre"];
            pedido[index].preciocompra = fila["preciocompra"];
            pedido[index].precioventa = fila["precioventa"];

            mostrarProductosAgregados();

        });
        
    }


    $("#btnMostrarProductos").on("click",mostrarModalConsultar);
    
    function mostrarModalConsultar(e){
      e.preventDefault();
      $("#formConsultar")[0].reset();
      $("#divConsultar").modal({backdrop: 'static', keyboard: false});
    }

    
     function mostrarProductosAgregados()
    {
      $("#tablaProductoSeleccionado  tbody tr").remove();
      var totalComprados = 0;
      for (var i = 0; i < pedido.length; i++) {
        var precio = parseFloat(pedido[i]["precioventa"]);
        var cantidad = parseInt(pedido[i]["cantidad"]);
        totalComprados += (precio * cantidad);
        $("<tr></tr>")
          .append( "<td>" + ( i + 1 ) + "</td>" )
          .append( "<td>" + pedido[i]["codigo"] + "</td>" )
          .append( "<td>" + pedido[i]["nombre"] + "</td>" )
          .append( "<td>" + cantidad + "</td>" )
          .append( "<td>" + precio.toFixed(2) + "</td>" )
          .append( $("<td></td>")
              .append( $( "<small class='btn-delete pull-right' style='cursor:pointer;'><i class='fa fa-times fa-2x'></i></small>" )
                  .on("click",{ indexx : i } , eliminarProductos ) )
            )
          .prependTo("#tablaProductoSeleccionado > tbody");
      }

      $("#tablaSubTotal #cantComprados").html(pedido.length );
      $("#tablaSubTotal #totalComprados").html(totalComprados.toFixed(2));


      $("#txttotalPagar").html(totalComprados.toFixed(2));
      $("#totalPagar").val(totalComprados.toFixed(2));
      

      $("#cantidad").val("1");
      $("#buscarCodigoqr").val("").focus();

    }


    function eliminarProductos(e){
      var idProductoUbicacion = pedido[e.data.indexx].idproductoubicacion;

      var filterData = pedidoConsolidado.filter(function(obj) {
        return obj.idproductoubicacion === idProductoUbicacion;
      });

      if (filterData.length > 0) {
        var index = filterData[0].index;
        pedidoConsolidado[index].cantidad -= 1; 
      }


      pedidoG = Array();
      pedidoG = pedido;
      pedido = Array();
      var x = 0;
      for (var i = 0; i < pedidoG.length; i++) {
        if (i != e.data.indexx) {          
          pedido[x] = Array();
          pedido[x] = pedidoG[i];
          x++;
        }
      }

      mostrarProductosAgregados();
    }



    $("#nit").keypress(function( event ) {
        if ( event.which == 13 ) {          
            $.post("funciones/ws_clientes.php", { accion:"buscarnit" , nit:$("#nit").val() }, function(data) {
          if(data.resultado)
            {
                $("#formCliente input").addClass("dirty");                      
                $("#formCliente #idCliente").val(data.registros[0]["id"]);
                $("#formCliente #nit").val(data.registros[0]["nit"]);
                $("#formCliente #nombre").val(data.registros[0]["nombreproveedor"]);
                $("#formCliente #telefono").val(data.registros[0]["telefono"]);
            }
            else{
              toastr.warning(data.mensaje,"Info");
            }
        }, "json")
        .fail(function()
        {
            toastr.error("no se pudo conectar al servidor", "Error Conexión");
        });

        }
    });

    $("#agregarCobro").on("click",function(e){
        
        bloquearPantalla("Espere por favor");


        var error = 0;

        var nit = $("#formCliente #nit").val().trim();

        if (nit.length == 0) {
            toastr.info("Ingrese nit del cliente", "Información");
            error++;
        }

        if (pedido.length == 0) {
            toastr.info("No hay productos a cobrar", "Información");
            error++;
        }

        if (error == 0) {
          $.post ("funciones/ws_productos.php" ,  { 
              accion: "cobrarproductos",  
              idcliente: $("#formCliente #idCliente").val(), 
              pedido    :  JSON.stringify(pedido)             
            }, function(data) {
                if(data.resultado)
                {
                  toastr.success(data.mensaje, "Exito");

                  setTimeout(function(){
                    desbloquearPantalla();
                    $("#agregarCobro").fadeIn( 200 );
                    ratPack.refresh();
                  },500);
                }else{
                  toastr.warning(data.mensaje,"Información");
                  setTimeout(function(){
                    desbloquearPantalla();
                    $("#agregarCobro").fadeIn( 200 );
                  },500);
                }

          }, "json")
          .fail(function()
          {
              setTimeout(function(){
                desbloquearPantalla();
                $("#agregarCobro").fadeIn( 200 );
              },500);
              toastr.error("no se pudo conectar al servidor", "Error Conexión");
          }); 
      }else{
        setTimeout(function(){
          desbloquearPantalla();
          $("#agregarCobro").fadeIn( 200 );
        },500);
      }
        



    });



    $("body").scrollTop(50);

  });

</script>