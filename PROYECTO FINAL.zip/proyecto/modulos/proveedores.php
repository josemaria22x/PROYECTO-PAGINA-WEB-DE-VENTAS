<?php
session_start();
require_once ("../funciones/classSQL.php");
$conexion = new conexion();
if($conexion->permisos($_SESSION['idtipousuario'],"3","acceso"))
{
?>
  
<section>
  <div class="section-body">
    <div class="pageheader">      
        <h2 class="titulo title-1"> Proveedores </h2> 
    </div>

   

    <div class="card">

      <div class="card-header">
        <div class="overview-wrap">
          

          <div class="panel-heading">      
          <?php if($conexion->permisos($_SESSION['idtipousuario'],"3","crear")) { ?>
            <a id="btnNuevoProveedor" data-toggle="modal" class="btn btn-primary btn-lg">Nuevo Proveedor</a>
          <?php } ?>
            
          </div>


        </div>
      </div>

      <div class="contentpanel">
        <div class="panel panel-default">

          <div class="card-body">
            <div  class="custom-table table-responsive table--no-card m-b-30">
                

              <table id="tablaProveedores" class="table table-borderless table-data3 table-earning" >
              <thead>
                <tr>  
                   <th>#</th>
                   <th>RUT</th>
                   <th>NOMBRE</th>
                   <th>DIRECCION</th>
                   <th>TELEFONO</th>
                   <th>PÁGINA WEB</th>
                   <th></th>
                </tr>
              </thead>
              <tbody></tbody>
            </table>


            </div>
          </div>
        </div>
      </div>

    </div>







    <div id="divNuevoProveedor" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog">
        <form id='formNuevoProveedor' class="form form-validate"  role="form"   method="post" >
          <div class="modal-content  panel panel-primary">
              <div class="card-head style-primary">
                <header>Nuevo Proveedor</header>
                  <a class="panel-close" data-dismiss="modal" aria-hidden="true">×</a>
              </div>
              <div class="card-body">

                

                <div class="form-group floating-label">
                  <input type="text" class="form-control" id="nitproveedor" name="nitproveedor" required >
                  <label for="nitproveedor">RUT:</label>
                </div>

                <div class="form-group floating-label">
                  <input type="text" class="form-control" id="nombreproveedor" name="nombreproveedor" required >
                  <label for="nombreproveedor">Nombre:</label>
                </div>                


                <div class="form-group">
                    <div class="list-group col-md-12">              
                        <div class="list-group-item">
                            <h4 class="list-group-item-heading">Dirección:</h4>
                            <div class="row">
                                <div class="col-md-3 col-xs-3">

                                    <div class="form-group floating-label">
                                        <input type="text" class="form-control" id="calle" name="calle" required >
                                        <label for="calle">Calle:</label>
                                    </div>
                
                                </div>

                                <div class="col-md-3 col-xs-3">
                                    <div class="form-group floating-label">
                                        <input type="text" class="form-control" id="numero" name="numero" required >
                                        <label for="numero">Numero:</label>
                                    </div>
                                </div>

                                <div class="col-md-3 col-xs-3">
                                    <div class="form-group floating-label">
                                        <input type="text" class="form-control" id="comuna" name="comuna" required >
                                        <label for="comuna">Comuna:</label>
                                    </div>
                                </div>

                                <div class="col-md-3 col-xs-3">
                                    <div class="form-group floating-label">
                                        <input type="text" class="form-control" id="ciudad" name="ciudad" required >
                                        <label for="ciudad">Ciudad:</label>
                                    </div>
                                </div>



                            </div>
                        </div>              
                    </div>
                </div>
                

              

                <div class="form-group floating-label">
                  <input type="text" class="form-control" id="telefono" name="telefono" required >
                  <label for="telefono">Teléfono:</label>
                </div>

                <div class="form-group floating-label">
                  <input type="text" class="form-control" id="email" name="email" required >
                  <label for="email">Página web:</label>
                </div>
                

              </div>
                  <div class="modal-footer">
                      <div class="response"></div>
                      <button type="button" id="btnGuardarNuevoProveedor" class="btn btn-primary">Guardar</button>
                      <button type="button" id="btnCancelarNuevoProveedor" class="btn btn-default" data-dismiss="modal">Cancelar</button>
                  </div>
          </div>
        </form>  
      </div>
    </div>




    <div id="divEditarProveedor" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog">
        <form id='formEditarProveedor' class="form form-validate"  role="form"   method="post" >
          <div class="modal-content  panel panel-warning">
              <div class="card-head style-warning">
                <header>Editar Proveedor</header>
                  <a class="panel-close" data-dismiss="modal" aria-hidden="true">×</a>
              </div>
              <div class="card-body">

                <input type="hidden" class="form-control" id="idProveedor" name="idProveedor"  >
               

                <div class="form-group floating-label">
                  <input type="text" class="form-control" id="nitproveedor" name="nitproveedor" required >
                  <label for="nitproveedor">RUT:</label>
                </div>

                <div class="form-group floating-label">
                  <input type="text" class="form-control" id="nombreproveedor" name="nombreproveedor" required >
                  <label for="nombreproveedor">Nombre:</label>
                </div>             
                

                <div class="form-group">
                    <div class="list-group col-md-12">              
                        <div class="list-group-item">
                            <h4 class="list-group-item-heading">Dirección:</h4>
                            <div class="row">
                                <div class="col-md-3 col-xs-3">

                                    <div class="form-group floating-label">
                                        <input type="text" class="form-control" id="calle" name="calle" required >
                                        <label for="calle">Calle:</label>
                                    </div>
                
                                </div>

                                <div class="col-md-3 col-xs-3">
                                    <div class="form-group floating-label">
                                        <input type="text" class="form-control" id="numero" name="numero" required >
                                        <label for="numero">Numero:</label>
                                    </div>
                                </div>

                                <div class="col-md-3 col-xs-3">
                                    <div class="form-group floating-label">
                                        <input type="text" class="form-control" id="comuna" name="comuna" required >
                                        <label for="comuna">Comuna:</label>
                                    </div>
                                </div>

                                <div class="col-md-3 col-xs-3">
                                    <div class="form-group floating-label">
                                        <input type="text" class="form-control" id="ciudad" name="ciudad" required >
                                        <label for="ciudad">Ciudad:</label>
                                    </div>
                                </div>



                            </div>
                        </div>              
                    </div>
                </div>
                


                <div class="form-group floating-label">
                  <input type="text" class="form-control" id="telefono" name="telefono" required >
                  <label for="telefono">Teléfono:</label>
                </div>

                <div class="form-group floating-label">
                  <input type="text" class="form-control" id="email" name="email" required >
                  <label for="email">Página web:</label>
                </div>
                

              </div>
                  <div class="modal-footer">
                      <div class="response"></div>
                      <button type="button" id="btnGuardarEditarProveedor" class="btn btn-warning">Guardar</button>
                      <button type="button" id="btnCancelarEditarProveedor" class="btn btn-default" data-dismiss="modal">Cancelar</button>
                  </div>
          </div>
        </form>  
      </div>
    </div>



    <div id="divEliminarProveedor" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog">
          <div class="modal-content  panel panel-danger">
                <div class="card-head style-danger">
                  <header>Eliminar Proveedor</header>
                    <a class="panel-close" data-dismiss="modal" aria-hidden="true">×</a>
                </div>
                <div class="card-body">
                    <div class="form-group floating-label">
                        <input type="hidden" name="ideliminarProveedor" id="ideliminarProveedor" class="form-control" />
                        <h4>¿Desea eliminar el registro?</h4>
                    </div>
                </div> <!-- /.panel-body-->
              <div class="modal-footer">
                  <div class="response"></div>
                  <button type="button" id="btnEliminarProveedor" class="btn btn-danger">Si estoy seguro</button>
                  <button type="button" id="btnCancelarEliminarProveedor" class="btn btn-default" data-dismiss="modal">Cancelar</button>
              </div>
          </div>
      </div>
    </div>
    
  </div><!--end .section-body -->
</section>

<?php 
}
?>


  
<script type="text/javascript">

  $(document).ready(function() {

    
    
    
    


    $(".select2-list").select2({ allowClear: true });

    var Acceso = 0;
    var Crear = 0;
    var Modificar = 0;
    var Eliminar = 0;
    var Consultar = 0;

    verficarPermisos();

    

    function verficarPermisos () {
        $.post("funciones/ws_usuarios.php", {accion:"consultarPermisos" , idmodulo:"3"} ,function(data)
        {
            if(data.resultado){
                Acceso = data.registros[0]["acceso"];
                Crear = data.registros[0]["crear"];
                Modificar = data.registros[0]["modificar"];
                Eliminar = data.registros[0]["eliminar"];
                Consultar = data.registros[0]["consultar"];
                
               mostrarProveedores();
            }
            else
              toastr.warning(data.mensaje,"Info");
        }, "json")
        .fail(function()
        {
            toastr.error("no se pudo conectar al servidor", "Error Conexión");
        });
    }
    
    

    

    function mostrarProveedores () {
      $("#tablaProveedores  tbody tr").remove();
      $.post("funciones/ws_proveedores.php", { accion: "mostrar" }, function(data) {
        if(data.resultado)
          {

            var btnEditar = "";
            var btnEliminar = "";
            var btnConsultar = "";

            $.each(data.registros,function(key,value) {

              if (Modificar == 1) {
                btnEditar = " <a style='cursor:pointer; ' href='#' title='Editar Proveedor'><i class='fa fa-edit fa-lg '></i></a>";
              };

              if (Eliminar == 1) {
                btnEliminar = " <a style='cursor:pointer' href='#' title='Eliminar Proveedor'> <i class='fa fa-trash fa-lg '></i></a>";
              };

              if (Consultar == 1) {
                btnConsultar = "<a  href='#' title='Compra Realizadas'> <i class='fa fa-eye fa-lg'></a>";
              };



              $("<tr></tr>")
                .append( "<td>" + (key + 1) + "</td>" )
                .append( "<td>" + value["nit"] + "</td>" )
                .append( "<td>" + value["nombreproveedor"] + "</td>" )
                .append( "<td>" + value["calle"] + ", " + value["numero"] + ", " + value["comuna"] + ", " + value["ciudad"] + "</td>" )
                .append( "<td>" + value["telefono"] + "</td>" )
                .append( "<td>" + value["email"] + "</td>" )
               .append( $("<td></td>")
                    .append( $(btnEditar)
                        .on("click" , { idProveedor:value["id"] } , editarProveedor ) )
                    .append( $(btnEliminar)
                        .on("click" , { idProveedor:value["id"] } , eliminarProveedor ) ) 
                  
                  )
                .appendTo("#tablaProveedores > tbody");
            });

                $("#tablaProveedores a").tooltip(); 
                $("#tablaProveedores").DataTable();

          }
          else{
            toastr.warning(data.mensaje,"Info");
          }
      }, "json")
      .fail(function()
      {
          toastr.error("no se pudo conectar al servidor", "Error Conexión");
      });

    }

    
    /****************** MOSTRAR MODAL NUEVO REGISTRO *******************/
    $("#btnNuevoProveedor").on("click",mostrarModalNuevoProveedor);
    
    function mostrarModalNuevoProveedor(e){
      e.preventDefault();
      $("#formNuevoProveedor")[0].reset();
      $("#formNuevoProveedor input").removeClass("dirty");
      $(".date").addClass("dirty");
      $("#divNuevoProveedor").modal("show", {backdrop: "static"});
    }


    /****************** GUARDAR DATOS DEL REGISTRO *******************/
    $("#btnGuardarNuevoProveedor").on("click",guardarNuevoProveedor);
    function guardarNuevoProveedor(e){
      e.preventDefault();
      if($("#formNuevoProveedor").valid()) {
          //console.log($("#formNuevoProveedor").serialize());
          $.post("funciones/ws_proveedores.php", "accion=nuevo&"+$("#formNuevoProveedor").serialize() ,function(data) {
            if(data.resultado){
                toastr.success(data.mensaje, "Exito");
                $("#divNuevoProveedor").modal("hide");
                setTimeout(function(){ratPack.refresh();},300);
            }
            else{
                toastr.warning(data.mensaje,"Info");
            }
          }, "json")
          .fail(function() {
            toastr.error("no se pudo conectar al servidor", "Error Conexión");
          });
      }
    }

    /******************  MUESTRA EL FORMULARIO PARA EDITAR LOS REGISTROS *******************/
    function editarProveedor (e) {
        e.preventDefault();
        $.post("funciones/ws_proveedores.php", { accion:"mostrar" , idProveedor:e.data.idProveedor }, function(data) {
          if(data.resultado)
            {
              $("#formEditarProveedor")[0].reset();
              $("#divEditarProveedor").modal("show", {backdrop: "static"});
              $("#formEditarProveedor input").addClass("dirty");
              
              $("#formEditarProveedor #idProveedor").val(data.registros[0]["id"]);
              $("#formEditarProveedor #nitproveedor").val(data.registros[0]["nit"]);
              $("#formEditarProveedor #nombreproveedor").val(data.registros[0]["nombreproveedor"]);
              $("#formEditarProveedor #telefono").val(data.registros[0]["telefono"]);
              $("#formEditarProveedor #email").val(data.registros[0]["email"]);
              $("#formEditarProveedor #calle").val(data.registros[0]["calle"]);
              $("#formEditarProveedor #numero").val(data.registros[0]["numero"]);
              $("#formEditarProveedor #comuna").val(data.registros[0]["comuna"]);
              $("#formEditarProveedor #ciudad").val(data.registros[0]["ciudad"]);
            }
            else{
              toastr.warning(data.mensaje,"Info");
            }
        }, "json")
        .fail(function()
        {
            toastr.error("no se pudo conectar al servidor", "Error Conexión");
        });
    }


    /****************** MODIFICAR DATOS DEL REGISTRO *******************/
    $("#btnGuardarEditarProveedor").on("click",guardarEditarProveedor);
    
    function guardarEditarProveedor(e){
      e.preventDefault();
      if($("#formEditarProveedor").valid()) {
          $.post("funciones/ws_proveedores.php", "accion=editar&"+$("#formEditarProveedor").serialize() ,function(data) {
            if(data.resultado){
                toastr.success(data.mensaje, "Exito");;
                $("#divEditarProveedor").modal("hide");
                setTimeout(function(){ratPack.refresh();},300);
            }
            else{
                toastr.warning(data.mensaje,"Info");
            }
          }, "json")
          .fail(function() {
            toastr.error("no se pudo conectar al servidor", "Error Conexión");
          });
      }
    }




    /******************  MUESTRA EL FORMULARIO PARA ELIMINAR LOS REGISTROS *******************/
    function eliminarProveedor (e) {
      e.preventDefault();
      $("#divEliminarProveedor").modal("show", {backdrop: "static"});
      $("#ideliminarProveedor").val(e.data.idProveedor);
    }
    

    /****************** MODIFICAR DATOS DEL REGISTRO *******************/
    $("#btnEliminarProveedor").on("click",guardarEliminarProveedor);
    
    function guardarEliminarProveedor(e){
        e.preventDefault();
        $.post("funciones/ws_proveedores.php", { idProveedor:$("#ideliminarProveedor").val() , accion:"eliminar" } ,function(data) {
          if(data.resultado){
              toastr.success(data.mensaje, "Exito");
              $("#divEliminarProveedor").modal("hide");
              setTimeout(function(){ratPack.refresh();},300);
          }
          else{
              toastr.warning(data.mensaje,"Info");
          }
        }, "json")
        .fail(function() {
          toastr.error("no se pudo conectar al servidor", "Error Conexión");
        });
    }



    
  });
</script>