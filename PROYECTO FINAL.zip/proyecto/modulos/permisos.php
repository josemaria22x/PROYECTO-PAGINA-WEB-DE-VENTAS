<?php
session_start();
require_once("../funciones/classSQL.php");
$conexion = new conexion();
if($conexion->permisos($_SESSION['idtipousuario'],"2","Acceso"))
{
?>
  

<section>
  <div class="section-body">

      <div class="pageheader">      
          <h2 class="titulo title-1"> Accesos </h2> 
      </div>

      <div class="card">

      

        <div class="contentpanel">
          <div class="panel panel-default">

            <div class="card-body">
              <div  class=" custom-table table-responsive table--no-card">
                <table id="tablaPermisos" class="table table-borderless table-data3 table-earning">
                  <thead>
                    <tr>  
                      <th>No.</th>
                      <th>TIPO USUARIO</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody></tbody>
                </table>
              </div>
            </div>
          </div>
        </div>


        </div>



      <br><br>




      




    <div id="divPermisosModulo" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <form id='formPermisosModulo' class="form form-validate"  role="form"   method="post" >
          <div class="modal-content  panel panel-primary">
              <div class="card-head style-primary">
                <header>Permisos por Modulo</header>
                  <a class="panel-close" data-dismiss="modal" aria-hidden="true">×</a>
              </div>
              <div class="card-body">

                <div id="divTablaDetalle" class="contentpanel" style="display:none;">
                  <div class="card">

                    <div class="panel panel-default">    
                      <div class="card-body">
                        <div  id="divTablaModulos" class="table-responsive " ></div>
                      </div>
                    </div>

                  </div>
                </div>


              </div>
                  <div class="modal-footer">
                      <div class="response"></div>
                      <button type="button" id="btnCancelarPermisosModulo" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                  </div>
          </div>
        </form>  
      </div>
    </div>


  </div><!--end .section-body -->
</section>


<?php 
}
 ?>
  
<script type="text/javascript">
  
  $(document).ready(function() {

    mostrarTiposUsuarios();

    function mostrarTiposUsuarios() {
      $("#tablaPermisos  tbody tr").remove();
      $.post("funciones/ws_tipousuarios.php", { accion: "mostrarTU" }, function(data) {
        if(data.resultado)
          {
            $.each(data.registros,function(key,value) {

              $("<tr  rel='"+value["id"]+"'></tr>")
                .append( "<td>" + (key + 1) + "</td>" )
                .append( "<td>" + value["descripcion"] + "</td>" )
                .append( $("<td></td>")

                .append( $("<div class='table-data-feature'></div>")
                .append( $("<a rel='" + value["id"] + "' href='#' title='ver modulos'  class='item'> <i class='fa fa-eye fa-lg'></a>")
                        .on("click", mostrarModulos) )
                
                )

                    
                        
                        

                  )
                .appendTo("#tablaPermisos > tbody");
            });

                $("#tablaPermisos a").tooltip(); 
                $("#tablaPermisos").DataTable();

          }
          else{
            toastr.warning(data.mensaje,"Info");
          }
      }, "json")
      .fail(function()
      {
          toastr.error("no se pudo conectar al servidor", "Error Conexión");
      });

    }

    function mostrarModulos (e) {
      e.preventDefault();
      

      $("#divPermisosModulo").modal("show", {backdrop: "static"});


      $("#divTablaDetalle").fadeIn("slow");
      $("#tablaModulos  tbody tr").remove();
      var idTipoUsuario = $(e.target).closest("a").attr("rel");

      $.post("funciones/ws_tipousuarios.php", { accion: "mostrarPU" , id : idTipoUsuario}, function(data) {
        if(data.resultado)
          { 
            var tabla =
            "<h3 id='tituloModulos' class='tituloH3'></h3><br>"+
            "<table id='tablaModulos' class='table order-column hover' >"+
              "<thead>"+
                "<tr>  "+
                   "<th>No.</th>"+
                   "<th>Modulo</th>"+
                   "<th>Acceso</th>"+
                   "<th>Crear</th>"+
                   "<th>Modificar</th>"+
                   "<th>Eliminar</th>"+
                   "<th>Consultar</th>"+
                "</tr>"+
              "</thead>"+
              "<tbody></tbody>"+
            "</table>";
            $("#divTablaModulos").html(tabla);

            $.each(data.registros,function(key,value) {
              $("#tituloModulos").html(value["tipousuario"]);

              $("<tr></tr>")
                .append( "<td>" + (key + 1) + "</td>" )
                .append( "<td>" + value["modulo"] + "</td>" )
                .append( "<td> <label class='au-checkbox'> <input type='checkbox' modulo='"+value["modulo"]+"' rel='"+value["Id"]+"' value='acceso'      "+value["acceso"]+"      /> <span class='au-checkmark'></span> </label> </td>" )
                .append( "<td> <label class='au-checkbox'> <input type='checkbox' modulo='"+value["modulo"]+"' rel='"+value["Id"]+"' value='crear'       "+value["crear"]+"       /> <span class='au-checkmark'></span> </label> </td>" )
                .append( "<td> <label class='au-checkbox'> <input type='checkbox' modulo='"+value["modulo"]+"' rel='"+value["Id"]+"' value='modificar'   "+value["modificar"]+"   /> <span class='au-checkmark'></span> </label> </td>" )
                .append( "<td> <label class='au-checkbox'> <input type='checkbox' modulo='"+value["modulo"]+"' rel='"+value["Id"]+"' value='eliminar'    "+value["eliminar"]+"    /> <span class='au-checkmark'></span> </label> </td>" )
                .append( "<td> <label class='au-checkbox'> <input type='checkbox' modulo='"+value["modulo"]+"' rel='"+value["Id"]+"' value='consultar'   "+value["consultar"]+"   /> <span class='au-checkmark'></span> </label> </td>" )
                .appendTo("#tablaModulos > tbody");
            });

               
                $("input[type='checkbox']").on('change', function() {  actualizarPermisos($(this)); });
                //$('#tablaModulos').ScrollTo();

          }
          else{
            toastr.warning(data.mensaje,"Info");
          }
      }, "json")
      .fail(function()
      {
          toastr.error("no se pudo conectar al servidor", "Error Conexión");
      });
    }


    function actualizarPermisos (input) {
      var id = input.attr("rel");
      var modulo = input.attr("modulo");
      var campo = input.val();
      var valor = "0";
      var mensaje = "El el Tipo Usuario NO puede "+campo+" en el modulo de "+modulo;
      if (input.prop('checked')){
        var valor = "1";
        var mensaje = "El el Tipo Usuario ya puede "+campo+" en el modulo de "+modulo;
      }

      $.post("funciones/ws_tipousuarios.php", { accion: "actializarPermiso" , id : id , campo : campo, valor : valor}, function(data) {
        if(data.resultado)
          {
            toastr.success(data.mensaje, "Exito");
          }
          else{
            toastr.warning(data.mensaje,"Info");
          }
      }, "json")
      .fail(function()
      {
          toastr.error("no se pudo conectar al servidor", "Error Conexión");
      });
    }


    

  });
</script>