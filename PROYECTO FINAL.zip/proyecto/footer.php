		
		</div><!--end #base-->
		<!-- END BASE -->

		<!-- BEGIN JAVASCRIPT -->
		<script src="js/libs/jquery/jquery-migrate-1.2.1.min.js"></script>
		<script src="js/libs/jquery-ui/jquery-ui.min.js"></script>
		<!--<script src="js/libs/bootstrap/bootstrap.min.js"></script>-->
		<script src="js/libs/spin.js/spin.min.js"></script>
		<script src="js/libs/autosize/jquery.autosize.min.js"></script>
		<script src="js/libs/moment/moment.js"></script>
		<script src="js/libs/select2/select2.min.js"></script>
		<script src="js/libs/multi-select/jquery.multi-select.js"></script>
		<script src="js/libs/bootstrap-tagsinput/bootstrap-tagsinput.min.js"></script>
		<script src="js/libs/inputmask/jquery.inputmask.bundle.min.js"></script>
		<script src="js/libs/typeahead/typeahead.bundle.min.js"></script>
		<!-- <script src="js/libs/utils/respond.js"></script> -->
		<script src="js/libs/dropzone/dropzone.min.js"></script>
		<script src="js/libs/flot/jquery.flot.min.js"></script>
		<script src="js/libs/flot/jquery.flot.time.min.js"></script>
		<script src="js/libs/flot/jquery.flot.resize.min.js"></script>
		<script src="js/libs/flot/jquery.flot.orderBars.js"></script>
		<script src="js/libs/flot/jquery.flot.pie.js"></script>
		<script src="js/libs/flot/curvedLines.js"></script>
		<script src="js/libs/jquery-knob/jquery.knob.min.js"></script>
		<script src="js/libs/sparkline/jquery.sparkline.min.js"></script>
		<script src="js/libs/nanoscroller/jquery.nanoscroller.min.js"></script>
		<script src="js/libs/d3/d3.min.js"></script>
		<script src="js/libs/d3/d3.v3.js"></script>
		<script src="js/libs/rickshaw/rickshaw.min.js"></script>
		

		<script src="js/libs/DataTables/jquery.dataTables.js"></script>
		<script src="js/libs/DataTables/extensions/ColVis/js/dataTables.colVis.js"></script>
		<script src="js/libs/DataTables/extensions/TableTools/js/dataTables.tableTools.js"></script>

		<script src="js/libs/bootstrap-datetimepicker/bootstrap-datetimepicker.js"></script>
		<script src="js/libs/jquery-validation/dist/jquery.validate.min.js"></script>
		<script src="js/libs/jquery-validation/dist/additional-methods.min.js"></script>

		<script src="js/libs/toastr/toastr.js"></script>
		<script src="js/libs/wizard/jquery.bootstrap.wizard.min.js"></script>

		<!-- <script src="http://maps.google.com/maps/api/js?sensor=true"></script> -->

		<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBWZ2D4tiIf1_VNAUokqRvxalUdXpbz4Qg"></script>
  		<script src="js/libs/gmaps/gmaps.js"></script>

  		 <!-- SCRIPT PARA LAS GRAFICAS -->
		<script src="js/libs/graficas/highcharts.js"></script>
		<script src="js/libs/graficas/exporting.js"></script>
		<script src="js/libs/graficas/highcharts-3d.js"></script>


		<!-- END JAVASCRIPT -->


		
		<!-- Bootstrap JS-->
		<script src="vendor/bootstrap-4.1/popper.min.js"></script>
		<script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
		<!-- Vendor JS       -->
		<script src="vendor/slick/slick.min.js"></script>
		<script src="vendor/wow/wow.min.js"></script>
		<script src="vendor/animsition/animsition.min.js"></script>
		<script src="vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
		</script>
		<script src="vendor/counter-up/jquery.waypoints.min.js"></script>
		<script src="vendor/counter-up/jquery.counterup.min.js">
		</script>
		<script src="vendor/circle-progress/circle-progress.min.js"></script>
		<script src="vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
		<script src="vendor/chartjs/Chart.bundle.min.js"></script>
		<script src="vendor/select2/select2.min.js">
		</script>

		<!-- Main JS-->
		<script src="js/main.js"></script>

	</body>
</html>